// Export pages
export '/account_profile_creation/userlogin/userlogin_widget.dart'
    show UserloginWidget;
export '/services/services_widget.dart' show ServicesWidget;
export '/initialpage/initialpage_widget.dart' show InitialpageWidget;
export '/account_profile_creation/doctorlogin/doctorlogin_widget.dart'
    show DoctorloginWidget;
export '/account_profile_creation/a_wlogin/a_wlogin_widget.dart'
    show AWloginWidget;
export '/awhp/awhp_widget.dart' show AwhpWidget;
export '/room/room_widget.dart' show RoomWidget;
export '/doctorpage/doctorpage_widget.dart' show DoctorpageWidget;
export '/userpage/userpage_widget.dart' show UserpageWidget;
export '/call/call_widget.dart' show CallWidget;
export '/docappointment/docappointment_widget.dart' show DocappointmentWidget;
export '/medicalhistory/medicalhistory/medicalhistory_widget.dart'
    show MedicalhistoryWidget;
export '/forgotpsswrd/forgotpsswrd_widget.dart' show ForgotpsswrdWidget;
export '/patientsrecord/patientsrecord_widget.dart' show PatientsrecordWidget;
export '/account_profile_creation/register/register_widget.dart'
    show RegisterWidget;
export '/jameswilson/jameswilson_widget.dart' show JameswilsonWidget;
export '/geminii/geminii_widget.dart' show GeminiiWidget;
export '/healthstatus/health/health_widget.dart' show HealthWidget;
export '/emmaedison/emmaedison_widget.dart' show EmmaedisonWidget;
export '/sarahrecord/sarahrecord_widget.dart' show SarahrecordWidget;
export '/bookingroomsuccesfful/bookingroomsuccesfful_widget.dart'
    show BookingroomsuccesffulWidget;
export '/michaeljohnson/michaeljohnson_widget.dart' show MichaeljohnsonWidget;
export '/emilypaulose/emilypaulose_widget.dart' show EmilypauloseWidget;
export '/healthstatus/healthai/healthai_widget.dart' show HealthaiWidget;
export '/booking/success/success_widget.dart' show SuccessWidget;
export '/patientsrecord_copy/patientsrecord_copy_widget.dart'
    show PatientsrecordCopyWidget;
export '/chat/chat_widget.dart' show ChatWidget;
export '/deficiency/deficiency_widget.dart' show DeficiencyWidget;
export '/duties/duties_widget.dart' show DutiesWidget;
export '/reportsawhp/reportsawhp_widget.dart' show ReportsawhpWidget;
export '/providernumber/providernumber_widget.dart' show ProvidernumberWidget;
export '/request/request_widget.dart' show RequestWidget;
export '/prescriptions/prescriptions_widget.dart' show PrescriptionsWidget;
export '/settings/settings_widget.dart' show SettingsWidget;
export '/language/language_widget.dart' show LanguageWidget;
