import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'hi', 'ml', 'ta'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? hiText = '',
    String? mlText = '',
    String? taText = '',
  }) =>
      [enText, hiText, mlText, taText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // Userlogin
  {
    'dbf5zcrv': {
      'en': 'User login',
      'hi': 'उपयोगकर्ता लॉगिन',
      'ml': 'ഉപയോക്തൃ ലോഗിൻ',
      'ta': 'பயனர் உள்நுழைவு',
    },
    '8ydmqtp7': {
      'en': 'Welcome Back',
      'hi': 'वापसी पर स्वागत है',
      'ml': 'തിരികെ സ്വാഗതം',
      'ta': 'மீண்டும் வருக',
    },
    'ja3p2uj4': {
      'en': 'Fill out the information below in order to access your account.',
      'hi': 'अपने खाते तक पहुंचने के लिए नीचे दी गई जानकारी भरें।',
      'ml':
          'നിങ്ങളുടെ അക്കൗണ്ട് ആക്‌സസ് ചെയ്യുന്നതിന് താഴെയുള്ള വിവരങ്ങൾ പൂരിപ്പിക്കുക.',
      'ta': 'உங்கள் கணக்கை அணுக கீழே உள்ள தகவல்களை நிரப்பவும்.',
    },
    'b61g72su': {
      'en': 'Email',
      'hi': 'ईमेल',
      'ml': 'ഇമെയിൽ',
      'ta': 'மின்னஞ்சல்',
    },
    'ftykr99m': {
      'en': 'Password',
      'hi': 'पासवर्ड',
      'ml': 'പാസ്‌വേഡ്',
      'ta': 'கடவுச்சொல்',
    },
    'zbid52h8': {
      'en': 'Sign In',
      'hi': 'दाखिल करना',
      'ml': 'സൈൻ ഇൻ',
      'ta': 'உள்நுழை',
    },
    '2uqa8hpx': {
      'en': 'Don\'t have an account?  ',
      'hi': 'क्या आपके पास खाता नहीं है?',
      'ml': 'അക്കൗണ്ട് ഇല്ലേ?',
      'ta': 'கணக்கு இல்லையா?',
    },
    's3nomuqa': {
      'en': 'Create Account',
      'hi': 'खाता बनाएं',
      'ml': 'അക്കൗണ്ട് സൃഷ്ടിക്കുക',
      'ta': 'கணக்கை உருவாக்கு',
    },
    'qmuky0ul': {
      'en': 'Forgot password?',
      'hi': 'पासवर्ड भूल गए?',
      'ml': 'പാസ്വേഡ് മറന്നോ?',
      'ta': 'கடவுச்சொல்லை மறந்துவிட்டீர்களா?',
    },
    'irhskpt3': {
      'en': 'Home',
      'hi': 'घर',
      'ml': 'വീട്',
      'ta': 'முகப்புப் பக்கம்',
    },
  },
  // services
  {
    '9dfxb2cd': {
      'en': 'Emergency Services',
      'hi': 'आपातकालीन सेवाएं',
      'ml': 'അടിയന്തര സേവനങ്ങൾ',
      'ta': 'அவசர சேவைகள்',
    },
    'g0pap5nx': {
      'en': 'Nearest Hospitals',
      'hi': 'निकटतम अस्पताल',
      'ml': 'ഏറ്റവും അടുത്തുള്ള ആശുപത്രികൾ',
      'ta': 'அருகிலுள்ள மருத்துவமனைகள்',
    },
    'qx11f67z': {
      'en': 'KIMS HOSPITAL',
      'hi': 'किम्स अस्पताल',
      'ml': 'കിംസ് ഹോസ്പിറ്റൽ',
      'ta': 'கிம்ஸ் மருத்துவமனை',
    },
    'to5tqv8c': {
      'en': '2.3 km away',
      'hi': '2.3 किमी दूर',
      'ml': '2.3 കിലോമീറ്റർ അകലെ',
      'ta': '2.3 கி.மீ தொலைவில்',
    },
    'idnt3alt': {
      'en': 'Emergency: +91 907 288 1666',
      'hi': 'आपातकालीन: +91 907 288 1666',
      'ml': 'അടിയന്തരാവസ്ഥ: +91 907 288 1666',
      'ta': 'அவசரநிலை: +91 907 288 1666',
    },
    'nanthz6e': {
      'en': 'ANANTHAPURI',
      'hi': 'अनंतपुरी',
      'ml': 'അനന്തപുരി',
      'ta': 'அனந்தபுரி',
    },
    'l5z9zkp0': {
      'en': '3.5 km away',
      'hi': '3.5 किमी दूर',
      'ml': '3.5 കിലോമീറ്റർ അകലെ',
      'ta': '3.5 கி.மீ தொலைவில்',
    },
    'b8zvwxmg': {
      'en': 'Emergency:  0471 - 2579900',
      'hi': 'आपातकालीन: 0471 - 2579900',
      'ml': 'അടിയന്തരാവസ്ഥ: 0471 - 2579900',
      'ta': 'அவசரநிலை: 0471 - 2579900',
    },
    'owh1s4o0': {
      'en': 'Ambulance Services',
      'hi': 'एम्बुलेंस सेवाएं',
      'ml': 'ആംബുലൻസ് സേവനങ്ങൾ',
      'ta': 'ஆம்புலன்ஸ் சேவைகள்',
    },
    'snkp3kwd': {
      'en': 'Rapid Response Ambulance',
      'hi': 'त्वरित प्रतिक्रिया एम्बुलेंस',
      'ml': 'റാപ്പിഡ് റെസ്പോൺസ് ആംബുലൻസ്',
      'ta': 'விரைவான பதிலளிப்பு ஆம்புலன்ஸ்',
    },
    '2ag9x9m2': {
      'en': 'Call Now: 6238977914',
      'hi': 'अभी कॉल करें: 6238977914',
      'ml': 'ഇപ്പോൾ വിളിക്കൂ: 6238977914',
      'ta': 'இப்போது அழைக்கவும்: 6238977914',
    },
    'qcaji24f': {
      'en': 'Available 24/7',
      'hi': '24/7 उपलब्ध',
      'ml': '24/7 ലഭ്യമാണ്',
      'ta': '24/7 கிடைக்கும்',
    },
    'fuwtulrc': {
      'en': 'Life Support Services',
      'hi': 'जीवन समर्थन सेवाएँ',
      'ml': 'ലൈഫ് സപ്പോർട്ട് സേവനങ്ങൾ',
      'ta': 'வாழ்க்கை ஆதரவு சேவைகள்',
    },
    'vtlasx58': {
      'en': 'Available 24/7',
      'hi': '24/7 उपलब्ध',
      'ml': '24/7 ലഭ്യമാണ്',
      'ta': '24/7 கிடைக்கும்',
    },
    'gtznz81y': {
      'en': 'Call Now: 6238977914',
      'hi': 'अभी कॉल करें: 6238977914',
      'ml': 'ഇപ്പോൾ വിളിക്കൂ: 6238977914',
      'ta': 'இப்போது அழைக்கவும்: 6238977914',
    },
    'lvh9ohd9': {
      'en': 'Dialysis Units',
      'hi': 'डायलिसिस इकाइयाँ',
      'ml': 'ഡയാലിസിസ് യൂണിറ്റുകൾ',
      'ta': 'டயாலிசிஸ் அலகுகள்',
    },
    '7of6nn4g': {
      'en': 'Kidney Care Center',
      'hi': 'किडनी केयर सेंटर',
      'ml': 'വൃക്ക പരിചരണ കേന്ദ്രം',
      'ta': 'சிறுநீரக பராமரிப்பு மையம்',
    },
    'rqm71vx7': {
      'en': 'Open: 8:00 AM - 8:00 PM',
      'hi': 'खुलने का समय: सुबह 8:00 बजे से शाम 8:00 बजे तक',
      'ml': 'തുറക്കുന്ന സമയം: രാവിലെ 8:00 - രാത്രി 8:00',
      'ta': 'திறந்திருக்கும் நேரம்: காலை 8:00 - இரவு 8:00',
    },
    'y2v79odx': {
      'en': 'Book Appointment: 555-0127',
      'hi': 'अपॉइंटमेंट बुक करें: 555-0127',
      'ml': 'ബുക്ക് അപ്പോയിന്റ്മെന്റ്: 555-0127',
      'ta': 'புத்தக முன்பதிவு: 555-0127',
    },
    'd2dxhbt7': {
      'en': 'Renal Care Unit',
      'hi': 'वृक्क देखभाल इकाई',
      'ml': 'വൃക്ക പരിചരണ യൂണിറ്റ്',
      'ta': 'சிறுநீரக பராமரிப்பு பிரிவு',
    },
    '8v2m8fdw': {
      'en': 'Open: 7:00 AM - 9:00 PM',
      'hi': 'खुला: सुबह 7:00 बजे से शाम 9:00 बजे तक',
      'ml': 'തുറക്കുന്ന സമയം: രാവിലെ 7:00 - രാത്രി 9:00',
      'ta': 'திறந்திருக்கும் நேரம்: காலை 7:00 மணி - இரவு 9:00 மணி',
    },
    'xwszhds8': {
      'en': 'Book Appointment: 555-0128',
      'hi': 'अपॉइंटमेंट बुक करें: 555-0128',
      'ml': 'ബുക്ക് അപ്പോയിന്റ്മെന്റ്: 555-0128',
      'ta': 'புத்தக முன்பதிவு: 555-0128',
    },
  },
  // initialpage
  {
    'h83jl2rt': {
      'en': 'Vcare',
      'hi': 'वीकेयर',
      'ml': 'വികെയർ',
      'ta': 'விகேர்',
    },
    'zcjoedzs': {
      'en': 'Welcome',
      'hi': 'स्वागत',
      'ml': 'സ്വാഗതം',
      'ta': 'வரவேற்பு',
    },
    'gcvw0rfe': {
      'en': 'Choose your login type to continue',
      'hi': 'जारी रखने के लिए अपना लॉगिन प्रकार चुनें',
      'ml': 'തുടരുന്നതിന് നിങ്ങളുടെ ലോഗിൻ തരം തിരഞ്ഞെടുക്കുക.',
      'ta': 'தொடர உங்கள் உள்நுழைவு வகையைத் தேர்வுசெய்யவும்.',
    },
    'olvi2m6i': {
      'en': 'Doctor Login',
      'hi': 'डॉक्टर लॉगिन',
      'ml': 'ഡോക്ടർ ലോഗിൻ',
      'ta': 'மருத்துவர் உள்நுழைவு',
    },
    'lhz0s63z': {
      'en': 'User Login',
      'hi': 'उपयोगकर्ता लॉगिन',
      'ml': 'ഉപയോക്തൃ ലോഗിൻ',
      'ta': 'பயனர் உள்நுழைவு',
    },
    '8b03eufz': {
      'en': 'Ashaworker Login',
      'hi': 'आशावर्कर लॉगिन',
      'ml': 'ആശാ വർക്കർ ലോഗിൻ',
      'ta': 'ஆஷா பணியாளர் உள்நுழைவு',
    },
  },
  // Doctorlogin
  {
    'ycsbz5za': {
      'en': 'Doctor login',
      'hi': 'डॉक्टर लॉगिन',
      'ml': 'ഡോക്ടർ ലോഗിൻ',
      'ta': 'மருத்துவர் உள்நுழைவு',
    },
    'dp2gmlck': {
      'en': 'Welcome Back',
      'hi': 'वापसी पर स्वागत है',
      'ml': 'തിരികെ സ്വാഗതം',
      'ta': 'மீண்டும் வருக',
    },
    '00v6vrgk': {
      'en': 'Fill out the information below in order to access your account.',
      'hi': 'अपने खाते तक पहुंचने के लिए नीचे दी गई जानकारी भरें।',
      'ml':
          'നിങ്ങളുടെ അക്കൗണ്ട് ആക്‌സസ് ചെയ്യുന്നതിന് താഴെയുള്ള വിവരങ്ങൾ പൂരിപ്പിക്കുക.',
      'ta': 'உங்கள் கணக்கை அணுக கீழே உள்ள தகவல்களை நிரப்பவும்.',
    },
    'p6fy8hmz': {
      'en': 'Email',
      'hi': 'ईमेल',
      'ml': 'ഇമെയിൽ',
      'ta': 'மின்னஞ்சல்',
    },
    'y86uuwcq': {
      'en': 'Password',
      'hi': 'पासवर्ड',
      'ml': 'പാസ്‌വേഡ്',
      'ta': 'கடவுச்சொல்',
    },
    'h4djlam7': {
      'en': 'Sign In',
      'hi': 'दाखिल करना',
      'ml': 'സൈൻ ഇൻ',
      'ta': 'உள்நுழை',
    },
    '8y4ymvt8': {
      'en': 'Don\'t have an account?  ',
      'hi': 'क्या आपके पास खाता नहीं है?',
      'ml': 'അക്കൗണ്ട് ഇല്ലേ?',
      'ta': 'கணக்கு இல்லையா?',
    },
    'gjlwwxjm': {
      'en': 'Create Account',
      'hi': 'खाता बनाएं',
      'ml': 'അക്കൗണ്ട് സൃഷ്ടിക്കുക',
      'ta': 'கணக்கை உருவாக்கு',
    },
    'vgqvn8tr': {
      'en': 'Forgot password?',
      'hi': 'पासवर्ड भूल गए?',
      'ml': 'പാസ്വേഡ് മറന്നോ?',
      'ta': 'கடவுச்சொல்லை மறந்துவிட்டீர்களா?',
    },
    'j3y9i83v': {
      'en': 'Home',
      'hi': 'घर',
      'ml': 'വീട്',
      'ta': 'முகப்புப் பக்கம்',
    },
  },
  // AWlogin
  {
    'vfrf10gb': {
      'en': 'Ashaworker \n        login',
      'hi': 'आशावर्कर\nलॉगिन',
      'ml': 'ആശാ വർക്കർ \nലോഗിൻ ചെയ്യുക',
      'ta': 'ஆஷா பணியாளர் \nஉள்நுழைவு',
    },
    'uan5r0zk': {
      'en': 'Welcome Back',
      'hi': 'वापसी पर स्वागत है',
      'ml': 'തിരികെ സ്വാഗതം',
      'ta': 'மீண்டும் வருக',
    },
    'ewvsbbbx': {
      'en': 'Fill out the information below in order to access your account.',
      'hi': 'अपने खाते तक पहुंचने के लिए नीचे दी गई जानकारी भरें।',
      'ml':
          'നിങ്ങളുടെ അക്കൗണ്ട് ആക്‌സസ് ചെയ്യുന്നതിന് താഴെയുള്ള വിവരങ്ങൾ പൂരിപ്പിക്കുക.',
      'ta': 'உங்கள் கணக்கை அணுக கீழே உள்ள தகவல்களை நிரப்பவும்.',
    },
    'mz1zo3eq': {
      'en': 'Email',
      'hi': 'ईमेल',
      'ml': 'ഇമെയിൽ',
      'ta': 'மின்னஞ்சல்',
    },
    'z20mfl45': {
      'en': 'Password',
      'hi': 'पासवर्ड',
      'ml': 'പാസ്‌വേഡ്',
      'ta': 'கடவுச்சொல்',
    },
    'xbbyogs6': {
      'en': 'Sign In',
      'hi': 'दाखिल करना',
      'ml': 'സൈൻ ഇൻ',
      'ta': 'உள்நுழை',
    },
    'w2230d03': {
      'en': 'Don\'t have an account?  ',
      'hi': 'क्या आपके पास खाता नहीं है?',
      'ml': 'അക്കൗണ്ട് ഇല്ലേ?',
      'ta': 'கணக்கு இல்லையா?',
    },
    '92ub5sar': {
      'en': 'Create Account',
      'hi': 'खाता बनाएं',
      'ml': 'അക്കൗണ്ട് സൃഷ്ടിക്കുക',
      'ta': 'கணக்கை உருவாக்கு',
    },
    '9ed40r95': {
      'en': 'Forgot password?',
      'hi': 'पासवर्ड भूल गए?',
      'ml': 'പാസ്വേഡ് മറന്നോ?',
      'ta': 'கடவுச்சொல்லை மறந்துவிட்டீர்களா?',
    },
    'fyrat0q4': {
      'en': 'Home',
      'hi': 'घर',
      'ml': 'വീട്',
      'ta': 'முகப்புப் பக்கம்',
    },
  },
  // AWHP
  {
    'wwpowo64': {
      'en': 'Welcome, Sudhaa',
      'hi': 'स्वागत है, सुधा!',
      'ml': 'സ്വാഗതം, സുധ.',
      'ta': 'வருக, சுதா.',
    },
    '14tfrdrn': {
      'en': 'Ashaworker • Kochi District',
      'hi': 'आशावर्कर • कोच्चि जिला',
      'ml': 'ആശാ വർക്കർ • കൊച്ചി ജില്ല',
      'ta': 'ஆஷா பணியாளர் • கொச்சி மாவட்டம்',
    },
    'v7oornkl': {
      'en': 'Quick Actions',
      'hi': 'त्वरित कार्रवाई',
      'ml': 'ദ്രുത പ്രവർത്തനങ്ങൾ',
      'ta': 'விரைவு செயல்கள்',
    },
    'tr4g2cor': {
      'en': 'Track Patients',
      'hi': 'मरीजों पर नज़र रखें',
      'ml': 'രോഗികളെ ട്രാക്ക് ചെയ്യുക',
      'ta': 'நோயாளிகளைக் கண்காணிக்கவும்',
    },
    'tuncft2p': {
      'en': 'Daily Tasks',
      'hi': 'दैनिक कार्यों',
      'ml': 'ദൈനംദിന ജോലികൾ',
      'ta': 'தினசரி பணிகள்',
    },
    'a6hrhfbw': {
      'en': 'Reports',
      'hi': 'रिपोर्टों',
      'ml': 'റിപ്പോർട്ടുകൾ',
      'ta': 'அறிக்கைகள்',
    },
    'ug3saz47': {
      'en': 'Today\'s Schedule',
      'hi': 'आज का कार्यक्रम',
      'ml': 'ഇന്നത്തെ ഷെഡ്യൂൾ',
      'ta': 'இன்றைய அட்டவணை',
    },
    'vofld3kj': {
      'en': 'Home Visit - Lakshmi M.',
      'hi': 'गृह भ्रमण - लक्ष्मी एम.',
      'ml': 'ഗൃഹസന്ദർശനം - ലക്ഷ്മി എം.',
      'ta': 'வீட்டு வருகை - லட்சுமி எம்.',
    },
    'rasq7hp0': {
      'en': '10:00 AM • Pregnancy Care',
      'hi': '10:00 AM • गर्भावस्था देखभाल',
      'ml': 'രാവിലെ 10:00 • ഗർഭകാല പരിചരണം',
      'ta': 'காலை 10:00 மணி • கர்ப்பகால பராமரிப்பு',
    },
    'rvcqmjtm': {
      'en': 'Vaccination Drive',
      'hi': 'टीकाकरण अभियान',
      'ml': 'വാക്സിനേഷൻ ഡ്രൈവ്',
      'ta': 'தடுப்பூசி இயக்கம்',
    },
    'qmpdltet': {
      'en': '2:00 PM • Community Center',
      'hi': '2:00 अपराह्न • सामुदायिक केंद्र',
      'ml': 'ഉച്ചയ്ക്ക് 2:00 • കമ്മ്യൂണിറ്റി സെന്റർ',
      'ta': 'பிற்பகல் 2:00 மணி • சமூக மையம்',
    },
    '93n88qkt': {
      'en': 'Training Resources',
      'hi': 'प्रशिक्षण संसाधन',
      'ml': 'പരിശീലന വിഭവങ്ങൾ',
      'ta': 'பயிற்சி வளங்கள்',
    },
    '5sq1r94w': {
      'en': 'Maternal Health Guidelines',
      'hi': 'मातृ स्वास्थ्य दिशानिर्देश',
      'ml': 'മാതൃ ആരോഗ്യ മാർഗ്ഗനിർദ്ദേശങ്ങൾ',
      'ta': 'தாய்வழி சுகாதார வழிகாட்டுதல்கள்',
    },
    'r0dx5r4k': {
      'en': 'Child Vaccination Protocol',
      'hi': 'बाल टीकाकरण प्रोटोकॉल',
      'ml': 'കുട്ടികളുടെ വാക്സിനേഷൻ പ്രോട്ടോക്കോൾ',
      'ta': 'குழந்தை தடுப்பூசி நெறிமுறை',
    },
    'ne1646ce': {
      'en': 'Community Updates',
      'hi': 'सामुदायिक अपडेट',
      'ml': 'കമ്മ്യൂണിറ്റി അപ്‌ഡേറ്റുകൾ',
      'ta': 'சமூக புதுப்பிப்புகள்',
    },
    'b9qttbt0': {
      'en': 'Upcoming Health Camp',
      'hi': 'आगामी स्वास्थ्य शिविर',
      'ml': 'വരാനിരിക്കുന്ന ആരോഗ്യ ക്യാമ്പ്',
      'ta': 'வரவிருக்கும் சுகாதார முகாம்',
    },
    'i88phmo6': {
      'en':
          'Join us for the community health camp this Sunday. Free health checkups and consultations available.',
      'hi':
          'इस रविवार को सामुदायिक स्वास्थ्य शिविर में हमारे साथ शामिल हों। निःशुल्क स्वास्थ्य जांच और परामर्श उपलब्ध है।',
      'ml':
          'ഈ ഞായറാഴ്ച നടക്കുന്ന കമ്മ്യൂണിറ്റി ഹെൽത്ത് ക്യാമ്പിൽ ഞങ്ങളോടൊപ്പം ചേരൂ. സൗജന്യ ആരോഗ്യ പരിശോധനകളും കൺസൾട്ടേഷനുകളും ലഭ്യമാണ്.',
      'ta':
          'இந்த ஞாயிற்றுக்கிழமை சமூக சுகாதார முகாமில் எங்களுடன் சேருங்கள். இலவச சுகாதார பரிசோதனைகள் மற்றும் ஆலோசனைகள் கிடைக்கின்றன.',
    },
    '3oodfhyz': {
      'en': 'Sunday, 10 AM - 4 PM',
      'hi': 'रविवार, सुबह 10 बजे - शाम 4 बजे',
      'ml': 'ഞായറാഴ്ച, രാവിലെ 10 മുതൽ വൈകുന്നേരം 4 വരെ',
      'ta': 'ஞாயிறு, காலை 10 மணி - மாலை 4 மணி',
    },
    'qmgnrbds': {
      'en': '            LOG OUT                 ',
      'hi': 'लॉग आउट',
      'ml': 'ലോഗ് ഔട്ട് ചെയ്യുക',
      'ta': 'வெளியேறு',
    },
  },
  // room
  {
    'gse23a5r': {
      'en': 'Room Booking',
      'hi': 'कमरा बुकिंग',
      'ml': 'മുറി ബുക്കിംഗ്',
      'ta': 'அறை முன்பதிவு',
    },
    '232emp48': {
      'en': 'Available Rooms',
      'hi': 'उपलब्ध कमरे',
      'ml': 'ലഭ്യമായ മുറികൾ',
      'ta': 'கிடைக்கும் அறைகள்',
    },
    '062mssaq': {
      'en': 'ICU',
      'hi': 'आईसीयू',
      'ml': 'ഐസിയു',
      'ta': 'ஐ.சி.யூ.',
    },
    '6844i4df': {
      'en': '3/5',
      'hi': '3/5',
      'ml': '3/5',
      'ta': '3/5',
    },
    '5400kpxk': {
      'en': 'Available',
      'hi': 'उपलब्ध',
      'ml': 'ലഭ്യമാണ്',
      'ta': 'கிடைக்கிறது',
    },
    '9rt1y4md': {
      'en': 'General',
      'hi': 'सामान्य',
      'ml': 'ജനറൽ',
      'ta': 'பொது',
    },
    'yd8a7a4h': {
      'en': '8/15',
      'hi': '8/15',
      'ml': '8/15',
      'ta': '8/15',
    },
    'fy9iu5oi': {
      'en': 'Available',
      'hi': 'उपलब्ध',
      'ml': 'ലഭ്യമാണ്',
      'ta': 'கிடைக்கிறது',
    },
    '5o43iinf': {
      'en': 'Private',
      'hi': 'निजी',
      'ml': 'സ്വകാര്യം',
      'ta': 'தனியார்',
    },
    '5yx3t58e': {
      'en': '4/10',
      'hi': '4/10',
      'ml': '4/10 закульный',
      'ta': '4/10',
    },
    'c4wekryk': {
      'en': 'Available',
      'hi': 'उपलब्ध',
      'ml': 'ലഭ്യമാണ്',
      'ta': 'கிடைக்கிறது',
    },
    'ozm6gj1g': {
      'en': 'Patient Name',
      'hi': 'मरीज का नाम',
      'ml': 'രോഗിയുടെ പേര്',
      'ta': 'நோயாளி பெயர்',
    },
    'lc5fjk7z': {
      'en': 'Check-in Date',
      'hi': 'चेक-इन तिथि',
      'ml': 'ചെക്ക്-ഇൻ തീയതി',
      'ta': 'வருகை தேதி',
    },
    'b85015y3': {
      'en': 'Enter Date',
      'hi': 'दिनांक दर्ज करें',
      'ml': 'തീയതി നൽകുക',
      'ta': 'தேதியை உள்ளிடவும்',
    },
    'eqjvb1gk': {
      'en': 'TextField',
      'hi': 'पाठ्य से भरा',
      'ml': 'ടെക്സ്റ്റ്ഫീൽഡ്',
      'ta': 'உரைப்புலம்',
    },
    'v2t5ypjk': {
      'en': 'Check-in Time',
      'hi': 'समय पर जांचो',
      'ml': 'ചെക്ക്-ഇൻ സമയം',
      'ta': 'செக்-இன் நேரம்',
    },
    'elt9l29b': {
      'en': 'Enter time',
      'hi': 'समय दर्ज करें',
      'ml': 'സമയം നൽകുക',
      'ta': 'நேரத்தை உள்ளிடவும்',
    },
    'nzk2vzdf': {
      'en': 'TextField',
      'hi': 'पाठ्य से भरा',
      'ml': 'ടെക്സ്റ്റ്ഫീൽഡ്',
      'ta': 'உரைப்புலம்',
    },
    'cue1fj7n': {
      'en': 'Room Type',
      'hi': 'कमरे के प्रकार',
      'ml': 'മുറിയുടെ തരം',
      'ta': 'அறை வகை',
    },
    'pvau9vrv': {
      'en': 'Select...',
      'hi': 'चुनना...',
      'ml': 'തിരഞ്ഞെടുക്കുക...',
      'ta': 'தேர்ந்தெடு...',
    },
    '8imazsvd': {
      'en': 'Search...',
      'hi': 'खोज...',
      'ml': 'തിരയുക...',
      'ta': 'தேடு...',
    },
    'g4lwziwe': {
      'en': 'S class',
      'hi': 'एस वर्ग',
      'ml': 'എസ് ക്ലാസ്',
      'ta': 'எஸ் வகுப்பு',
    },
    'zzoww7s0': {
      'en': 'A class',
      'hi': 'एक वर्ग',
      'ml': 'ഒരു ക്ലാസ്',
      'ta': 'ஒரு வகுப்பு',
    },
    'd7kt3glf': {
      'en': 'B class',
      'hi': 'बी वर्ग',
      'ml': 'ബി ക്ലാസ്',
      'ta': 'பி வகுப்பு',
    },
    'r75qitwq': {
      'en': 'C class',
      'hi': 'सी क्लास',
      'ml': 'സി ക്ലാസ്',
      'ta': 'சி வகுப்பு',
    },
    'c53dxccz': {
      'en': 'Special Requirements',
      'hi': 'विशेष ज़रूरतें',
      'ml': 'പ്രത്യേക ആവശ്യകതകൾ',
      'ta': 'சிறப்புத் தேவைகள்',
    },
    'gdmwomyk': {
      'en': 'Request Booking',
      'hi': 'बुकिंग का अनुरोध करें',
      'ml': 'ബുക്കിംഗ് അഭ്യർത്ഥിക്കുക',
      'ta': 'முன்பதிவு கோரிக்கை',
    },
  },
  // Doctorpage
  {
    'yxeo1n6d': {
      'en': 'Dr. Rekha Rishad',
      'hi': 'डॉ. रेखा रिशाद',
      'ml': 'ഡോ. രേഖ റിഷാദ്',
      'ta': 'டாக்டர் ரேகா ரிஷாத்',
    },
    'wti1ltbi': {
      'en': 'General Physician',
      'hi': 'सामान्य चिकित्सक',
      'ml': 'ജനറൽ ഫിസിഷ്യൻ',
      'ta': 'பொது மருத்துவர்',
    },
    'tkkeeuqk': {
      'en': 'Today\'s Appointments',
      'hi': 'आज की नियुक्तियाँ',
      'ml': 'ഇന്നത്തെ അപ്പോയിന്റ്മെന്റുകൾ',
      'ta': 'இன்றைய சந்திப்புகள்',
    },
    'p6ri6esk': {
      'en': '8 Patients',
      'hi': '8 मरीज़',
      'ml': '8 രോഗികൾ',
      'ta': '8 நோயாளிகள்',
    },
    'xw0c11uw': {
      'en': 'View All',
      'hi': 'सभी को देखें',
      'ml': 'എല്ലാം കാണുക',
      'ta': 'அனைத்தையும் காண்க',
    },
    'cvdw4a5t': {
      'en': 'James Wilson',
      'hi': 'जेम्स विल्सन',
      'ml': 'ജെയിംസ് വിൽസൺ',
      'ta': 'ஜேம்ஸ் வில்சன்',
    },
    'p6ievye4': {
      'en': '2:30pm • checkup',
      'hi': '2:30 बजे • चेकअप',
      'ml': 'ഉച്ചയ്ക്ക് 2:30 • പരിശോധന',
      'ta': 'மதியம் 2:30 மணி • பரிசோதனை',
    },
    '6z9jyixi': {
      'en': 'Details',
      'hi': 'विवरण',
      'ml': 'വിശദാംശങ്ങൾ',
      'ta': 'விவரங்கள்',
    },
    'r93pf8cs': {
      'en': 'Emma edison',
      'hi': 'एम्मा एडिसन',
      'ml': 'എമ്മ എഡിസൺ',
      'ta': 'எம்மா எடிசன்',
    },
    'gn1xvebc': {
      'en': '3:00pm • Checkup',
      'hi': '3:00 बजे • चेकअप',
      'ml': 'ഉച്ചകഴിഞ്ഞ് 3:00 • പരിശോധന',
      'ta': 'பிற்பகல் 3:00 மணி • பரிசோதனை',
    },
    '5smfnmez': {
      'en': 'Details',
      'hi': 'विवरण',
      'ml': 'വിശദാംശങ്ങൾ',
      'ta': 'விவரங்கள்',
    },
    '7rcmgz5j': {
      'en': 'ASHA Worker Collaboration',
      'hi': 'आशा कार्यकर्ता सहयोग',
      'ml': 'ആശാ വർക്കർ സഹകരണം',
      'ta': 'ஆஷா பணியாளர் ஒத்துழைப்பு',
    },
    'eepbbgcw': {
      'en': 'SUDHAA',
      'hi': 'सुधा',
      'ml': 'സുധാ',
      'ta': 'சுதா',
    },
    'db0j4d28': {
      'en': '1 patient update',
      'hi': '1 मरीज़ अपडेट',
      'ml': 'ഒരു രോഗിയുടെ അപ്‌ഡേറ്റ്',
      'ta': '1 நோயாளி புதுப்பிப்பு',
    },
    '9m5c8y5l': {
      'en': 'Review',
      'hi': 'समीक्षा',
      'ml': 'അവലോകനം',
      'ta': 'விமர்சனம்',
    },
    'fsis8eat': {
      'en': 'Patient Records',
      'hi': 'मरीज़ों के रिकॉर्ड',
      'ml': 'രോഗി രേഖകൾ',
      'ta': 'நோயாளி பதிவுகள்',
    },
    'x1wugkv2': {
      'en': 'View and manage patient history',
      'hi': 'रोगी का इतिहास देखें और प्रबंधित करें',
      'ml': 'രോഗിയുടെ ചരിത്രം കാണുക, കൈകാര്യം ചെയ്യുക',
      'ta': 'நோயாளி வரலாற்றைப் பார்த்து நிர்வகிக்கவும்',
    },
    'f7chgqe3': {
      'en': 'Prescriptions',
      'hi': 'नुस्खे',
      'ml': 'കുറിപ്പടികൾ',
      'ta': 'மருந்துச்சீட்டுகள்',
    },
    'bthr3hfh': {
      'en': 'Update and track medications',
      'hi': 'दवाओं को अपडेट करें और ट्रैक करें',
      'ml': 'മരുന്നുകൾ അപ്ഡേറ്റ് ചെയ്യുകയും ട്രാക്ക് ചെയ്യുകയും ചെയ്യുക',
      'ta': 'மருந்துகளைப் புதுப்பித்து கண்காணிக்கவும்',
    },
    'mhbrxvbq': {
      'en': 'Log out',
      'hi': 'लॉग आउट',
      'ml': 'ലോഗ് ഔട്ട് ചെയ്യുക',
      'ta': 'வெளியேறு',
    },
    'sfv58tr3': {
      'en': 'Button',
      'hi': 'बटन',
      'ml': 'ബട്ടൺ',
      'ta': 'பொத்தான்',
    },
    'lwuhw1on': {
      'en': 'Review',
      'hi': 'समीक्षा',
      'ml': 'അവലോകനം',
      'ta': 'விமர்சனம்',
    },
    'n4o8uwiu': {
      'en': 'Review',
      'hi': 'समीक्षा',
      'ml': 'അവലോകനം',
      'ta': 'விமர்சனம்',
    },
    'tymriclq': {
      'en': 'Review',
      'hi': 'समीक्षा',
      'ml': 'അവലോകനം',
      'ta': 'விமர்சனம்',
    },
  },
  // userpage
  {
    '6qvy047a': {
      'en': 'Welcome, Sarah',
      'hi': 'स्वागत है, सारा',
      'ml': 'സ്വാഗതം, സാറാ.',
      'ta': 'வரவேற்கிறோம், சாரா.',
    },
    '1z5p6mw6': {
      'en': 'Take control of your health journey',
      'hi': 'अपनी स्वास्थ्य यात्रा पर नियंत्रण रखें',
      'ml': 'നിങ്ങളുടെ ആരോഗ്യ യാത്രയുടെ നിയന്ത്രണം ഏറ്റെടുക്കുക',
      'ta': 'உங்கள் உடல்நலப் பயணத்தைக் கட்டுப்படுத்துங்கள்.',
    },
    'zz56j27a': {
      'en': 'Upcoming Appointments',
      'hi': 'आगामी नियुक्तियाँ',
      'ml': 'വരാനിരിക്കുന്ന അപ്പോയിന്റ്മെന്റുകൾ',
      'ta': 'வரவிருக்கும் சந்திப்புகள்',
    },
    'k0zov9oh': {
      'en': 'View All',
      'hi': 'सभी को देखें',
      'ml': 'എല്ലാം കാണുക',
      'ta': 'அனைத்தையும் காண்க',
    },
    '4tud5yp6': {
      'en': 'Dr.Rekha Rishad',
      'hi': 'डॉ. रेखा रिशाद',
      'ml': 'ഡോ.രേഖ റിഷാദ്',
      'ta': 'டாக்டர் ரேகா ரிஷாத்',
    },
    'qy24jzqw': {
      'en': 'General Physician',
      'hi': 'सामान्य चिकित्सक',
      'ml': 'ജനറൽ ഫിസിഷ്യൻ',
      'ta': 'பொது மருத்துவர்',
    },
    'c3l0sr6n': {
      'en': 'Confirmed',
      'hi': 'की पुष्टि',
      'ml': 'സ്ഥിരീകരിച്ചു',
      'ta': 'உறுதிப்படுத்தப்பட்டது',
    },
    'atbv13mh': {
      'en': 'Tomorrow, 2:00 AM',
      'hi': 'कल, 2:00 पूर्वाह्न',
      'ml': 'നാളെ, പുലർച്ചെ 2:00 മണിക്ക്',
      'ta': 'நாளை, அதிகாலை 2:00 மணி',
    },
    '6ngbno3s': {
      'en': 'Quick Actions',
      'hi': 'त्वरित कार्रवाई',
      'ml': 'ദ്രുത പ്രവർത്തനങ്ങൾ',
      'ta': 'விரைவு செயல்கள்',
    },
    'ej72ypj0': {
      'en': 'Schedule Visit',
      'hi': 'यात्रा का कार्यक्रम तय करें',
      'ml': 'സന്ദർശനം ഷെഡ്യൂൾ ചെയ്യുക',
      'ta': 'வருகை அட்டவணை',
    },
    'mfigvmyy': {
      'en': 'Medical History',
      'hi': 'चिकित्सा का इतिहास',
      'ml': 'മെഡിക്കൽ ചരിത്രം',
      'ta': 'மருத்துவ வரலாறு',
    },
    'z7qk4m8j': {
      'en': 'Book Room',
      'hi': 'कमरा बुक करें',
      'ml': 'ബുക്ക് റൂം',
      'ta': 'அறையை முன்பதிவு செய்யவும்',
    },
    '2xn2whs1': {
      'en': 'HELP',
      'hi': 'मदद',
      'ml': 'സഹായം',
      'ta': 'உதவி',
    },
    '91b4u9wn': {
      'en': 'HealthStatus',
      'hi': 'स्वास्थ्यस्थिति',
      'ml': 'ആരോഗ്യസ്ഥിതി',
      'ta': 'சுகாதார நிலை',
    },
    'sl8xlj1d': {
      'en': 'Emergency',
      'hi': 'आपातकाल',
      'ml': 'അടിയന്തരാവസ്ഥ',
      'ta': 'அவசரம்',
    },
    'yim7g3hz': {
      'en': 'Dr AI',
      'hi': 'डॉ. ए.आई.',
      'ml': 'ഡോ. എ.ഐ.',
      'ta': 'டாக்டர் ஏஐ',
    },
    'e417jgs0': {
      'en': 'Recent Health Updates',
      'hi': 'हालिया स्वास्थ्य अपडेट',
      'ml': 'സമീപകാല ആരോഗ്യ അപ്‌ഡേറ്റുകൾ',
      'ta': 'சமீபத்திய சுகாதார புதுப்பிப்புகள்',
    },
    '6ysniht5': {
      'en': 'Blood Test Results',
      'hi': 'रक्त परीक्षण के परिणाम',
      'ml': 'രക്തപരിശോധനാ ഫലങ്ങൾ',
      'ta': 'இரத்த பரிசோதனை முடிவுகள்',
    },
    'fo84esli': {
      'en': 'Your recent blood work results are ready',
      'hi': 'आपके हालिया रक्त परीक्षण के परिणाम तैयार हैं',
      'ml': 'നിങ്ങളുടെ സമീപകാല രക്തപരിശോധനാ ഫലങ്ങൾ തയ്യാറാണ്.',
      'ta': 'உங்கள் சமீபத்திய இரத்த பரிசோதனை முடிவுகள் தயாராக உள்ளன.',
    },
    'a4ulvm9m': {
      'en': '2 hours ago',
      'hi': '2 घंटे पहले',
      'ml': '2 മണിക്കൂർ മുമ്പ്',
      'ta': '2 மணி நேரத்திற்கு முன்பு',
    },
    'l5u0avic': {
      'en': 'Medication Reminder',
      'hi': 'दवा अनुस्मारक',
      'ml': 'മരുന്ന് ഓർമ്മപ്പെടുത്തൽ',
      'ta': 'மருந்து நினைவூட்டல்',
    },
    'c89elp3n': {
      'en': 'Time to take your evening medication',
      'hi': 'शाम की दवा लेने का समय',
      'ml': 'വൈകുന്നേരത്തെ മരുന്ന് കഴിക്കാൻ സമയമായി',
      'ta': 'மாலை மருந்து எடுத்துக்கொள்ள வேண்டிய நேரம் இது.',
    },
    'nbnlsxtq': {
      'en': '4 hours ago',
      'hi': '4 घंटे पहले',
      'ml': '4 മണിക്കൂർ മുമ്പ്',
      'ta': '4 மணி நேரத்திற்கு முன்பு',
    },
    'avn3o8s5': {
      'en': 'Your ASHA Worker',
      'hi': 'आपकी आशा कार्यकर्ता',
      'ml': 'നിങ്ങളുടെ ആശാ വർക്കർ',
      'ta': 'உங்கள் ஆஷா பணியாளர்',
    },
    'w9ifbn6a': {
      'en': 'Mrs. Priya Kumar',
      'hi': 'श्रीमती प्रिया कुमार',
      'ml': 'ശ്രീമതി പ്രിയ കുമാർ',
      'ta': 'திருமதி பிரியா குமார்',
    },
    's8kdn1kg': {
      'en': 'Available for consultation',
      'hi': 'परामर्श के लिए उपलब्ध',
      'ml': 'കൺസൾട്ടേഷനായി ലഭ്യമാണ്',
      'ta': 'ஆலோசனைக்குக் கிடைக்கிறது',
    },
    'ur0ly8u4': {
      'en': 'Contact Now',
      'hi': 'अभी संपर्क करें',
      'ml': 'ഇപ്പോൾ ബന്ധപ്പെടുക',
      'ta': 'இப்போது தொடர்பு கொள்ளவும்',
    },
    'djlguldz': {
      'en': 'LOG OUT',
      'hi': 'लॉग आउट',
      'ml': 'ലോഗ് ഔട്ട് ചെയ്യുക',
      'ta': 'வெளியேறு',
    },
  },
  // call
  {
    'ovbxii43': {
      'en': 'Contact Details',
      'hi': 'सम्पर्क करने का विवरण',
      'ml': 'ബന്ധപ്പെടാനുള്ള വിശദാംശങ്ങൾ',
      'ta': 'தொடர்பு விவரங்கள்',
    },
    'kubxnkn7': {
      'en': 'Emergency Contact',
      'hi': 'आपातकालीन संपर्क',
      'ml': 'അടിയന്തര കോൺടാക്റ്റ്',
      'ta': 'அவசர தொடர்பு',
    },
    'ejnidcbx': {
      'en': 'Phone Number',
      'hi': 'फ़ोन नंबर',
      'ml': 'ഫോൺ നമ്പർ',
      'ta': 'தொலைபேசி எண்',
    },
    'ac673y4w': {
      'en': '+91 6238977914',
      'hi': '+91 6238977914',
      'ml': '+91 6238977914',
      'ta': '+91 6238977914',
    },
    '8g47246k': {
      'en': 'Available 24/7 for emergency assistance',
      'hi': 'आपातकालीन सहायता के लिए 24/7 उपलब्ध',
      'ml': 'അടിയന്തര സഹായത്തിന് 24/7 ലഭ്യമാണ്',
      'ta': 'அவசர உதவிக்கு 24/7 கிடைக்கும்',
    },
    'cmtr36nm': {
      'en': 'Additional Information',
      'hi': 'अतिरिक्त जानकारी',
      'ml': 'അധിക വിവരം',
      'ta': 'கூடுதல் தகவல்',
    },
    'bupo54bu': {
      'en': 'Main Hospital Building, Floor 2',
      'hi': 'मुख्य अस्पताल भवन, दूसरी मंज़िल',
      'ml': 'മെയിൻ ആശുപത്രി കെട്ടിടം, നില 2',
      'ta': 'பிரதான மருத்துவமனை கட்டிடம், தளம் 2',
    },
    '98g7yf96': {
      'en': 'Response Time: < 5 minutes',
      'hi': 'प्रतिक्रिया समय: < 5 मिनट',
      'ml': 'പ്രതികരണ സമയം: < 5 മിനിറ്റ്',
      'ta': 'மறுமொழி நேரம்: < 5 நிமிடங்கள்',
    },
    'x2uvsay1': {
      'en': 'For non-emergencies, please use the contact form',
      'hi': 'गैर-आपातकालीन स्थितियों के लिए, कृपया संपर्क फ़ॉर्म का उपयोग करें',
      'ml': 'അടിയന്തര സാഹചര്യങ്ങൾ ഒഴികെ, ദയവായി കോൺടാക്റ്റ് ഫോം ഉപയോഗിക്കുക.',
      'ta': 'அவசரநிலை அல்லாதவற்றுக்கு, தொடர்பு படிவத்தைப் பயன்படுத்தவும்.',
    },
    'a7uxomt0': {
      'en': 'CALL NOW',
      'hi': 'अब कॉल करें',
      'ml': 'ഇപ്പോൾ വിളിക്കൂ',
      'ta': 'இப்போதே அழைக்கவும்',
    },
  },
  // docappointment
  {
    'yo7eis5z': {
      'en': 'Schedule Visit',
      'hi': 'यात्रा का कार्यक्रम तय करें',
      'ml': 'സന്ദർശനം ഷെഡ്യൂൾ ചെയ്യുക',
      'ta': 'வருகை அட்டவணை',
    },
    'qwd2u3sa': {
      'en': 'Select Doctor',
      'hi': 'डॉक्टर चुनें',
      'ml': 'ഡോക്ടറെ തിരഞ്ഞെടുക്കുക',
      'ta': 'மருத்துவரைத் தேர்ந்தெடுக்கவும்',
    },
    '6cbwc28i': {
      'en': 'Dr. REKHA RISHAD',
      'hi': 'डॉ. रेखा रिशाद',
      'ml': 'ഡോ. രേഖ റിഷാദ്',
      'ta': 'டாக்டர் ரேகா ரிஷாத்',
    },
    'fbbvxiza': {
      'en': 'GENERAL PHYSICIAN',
      'hi': 'सामान्य चिकित्सक',
      'ml': 'ജനറൽ ഫിസിഷ്യൻ',
      'ta': 'பொது மருத்துவர்',
    },
    'yev8aily': {
      'en': 'Select Date & Time',
      'hi': 'दिनांक और समय चुनें',
      'ml': 'തീയതിയും സമയവും തിരഞ്ഞെടുക്കുക',
      'ta': 'தேதி & நேரத்தைத் தேர்ந்தெடுக்கவும்',
    },
    'o8drd1qd': {
      'en': 'Enter Date',
      'hi': 'दिनांक दर्ज करें',
      'ml': 'തീയതി നൽകുക',
      'ta': 'தேதியை உள்ளிடவும்',
    },
    'ffs9mvs6': {
      'en': 'TextField',
      'hi': 'पाठ्य से भरा',
      'ml': 'ടെക്സ്റ്റ്ഫീൽഡ്',
      'ta': 'உரைப்புலம்',
    },
    'ikiydw5n': {
      'en': 'Enter time',
      'hi': 'समय दर्ज करें',
      'ml': 'സമയം നൽകുക',
      'ta': 'நேரத்தை உள்ளிடவும்',
    },
    'z4jgyti1': {
      'en': 'TextField',
      'hi': 'पाठ्य से भरा',
      'ml': 'ടെക്സ്റ്റ്ഫീൽഡ്',
      'ta': 'உரைப்புலம்',
    },
    'yxdng2wn': {
      'en': 'Available Slots',
      'hi': 'उपलब्ध स्लॉट',
      'ml': 'ലഭ്യമായ സ്ലോട്ടുകൾ',
      'ta': 'கிடைக்கும் இடங்கள்',
    },
    'u7vule4v': {
      'en': '09:00 AM',
      'hi': '09:00 पूर्वाह्न',
      'ml': 'രാവിലെ 09:00',
      'ta': 'காலை 09:00 மணி',
    },
    '9p3vcz7b': {
      'en': '10:00 AM',
      'hi': '10:00 AM',
      'ml': 'രാവിലെ 10:00',
      'ta': 'காலை 10:00 மணி',
    },
    '4uigdwww': {
      'en': '11:30 AM',
      'hi': '11:30:00 बजे सुबह',
      'ml': 'രാവിലെ 11:30',
      'ta': 'காலை 11:30 மணி',
    },
    '2echx3ix': {
      'en': '02:00 PM',
      'hi': '02:00 अपराह्न',
      'ml': 'ഉച്ചയ്ക്ക് 02:00',
      'ta': 'பிற்பகல் 02:00 மணி',
    },
    '0okpyi73': {
      'en': '03:30 PM',
      'hi': '03:30 अपराह्न',
      'ml': 'ഉച്ചയ്ക്ക് 03:30',
      'ta': 'பிற்பகல் 03:30 மணி',
    },
    'hwup7lzw': {
      'en': 'Visit Details',
      'hi': 'यात्रा विवरण',
      'ml': 'വിശദാംശങ്ങൾ സന്ദർശിക്കുക',
      'ta': 'வருகை விவரங்கள்',
    },
    '1uxlyg72': {
      'en': 'Reason for Visit',
      'hi': 'यात्रा का कारण',
      'ml': 'സന്ദർശിക്കാനുള്ള കാരണം',
      'ta': 'வருகைக்கான காரணம்',
    },
    'duht7drz': {
      'en': 'First Visit?',
      'hi': 'पहली यात्रा?',
      'ml': 'ആദ്യ സന്ദർശനം?',
      'ta': 'முதல் வருகையா?',
    },
    'jrlqfaln': {
      'en': 'Schedule Appointment',
      'hi': 'नियुक्ति की सूची बनाना',
      'ml': 'അപ്പോയിന്റ്മെന്റ് ഷെഡ്യൂൾ ചെയ്യുക',
      'ta': 'சந்திப்பைத் திட்டமிடுங்கள்',
    },
  },
  // medicalhistory
  {
    '83h1gmdz': {
      'en': 'Medical History',
      'hi': 'चिकित्सा का इतिहास',
      'ml': 'മെഡിക്കൽ ചരിത്രം',
      'ta': 'மருத்துவ வரலாறு',
    },
    'jcbptqzp': {
      'en': 'Patient Information & Records',
      'hi': 'रोगी सूचना एवं रिकॉर्ड',
      'ml': 'രോഗി വിവരങ്ങളും രേഖകളും',
      'ta': 'நோயாளி தகவல் & பதிவுகள்',
    },
    'ylhrhqkj': {
      'en': 'Personal Information',
      'hi': 'व्यक्तिगत जानकारी',
      'ml': 'സ്വകാര്യ വിവരം',
      'ta': 'தனிப்பட்ட தகவல்',
    },
    'k8iaz65q': {
      'en': 'Full Name',
      'hi': 'पूरा नाम',
      'ml': 'പൂർണ്ണമായ പേര്',
      'ta': 'முழு பெயர்',
    },
    'ns1t2kwf': {
      'en': 'Sarah Johnson',
      'hi': 'सारा जॉनसन',
      'ml': 'സാറാ ജോൺസൺ',
      'ta': 'சாரா ஜான்சன்',
    },
    'r5h9pa51': {
      'en': 'Date of Birth',
      'hi': 'जन्म तिथि',
      'ml': 'ജനനത്തീയതി',
      'ta': 'பிறந்த தேதி',
    },
    '9846mhtc': {
      'en': '15 March 1985',
      'hi': '15 मार्च 1985',
      'ml': '1985 മാർച്ച് 15',
      'ta': '15 மார்ச் 1985',
    },
    '0z3wumwb': {
      'en': 'Phone Number',
      'hi': 'फ़ोन नंबर',
      'ml': 'ഫോൺ നമ്പർ',
      'ta': 'தொலைபேசி எண்',
    },
    '2znlutj5': {
      'en': '9687706959',
      'hi': '9687706959',
      'ml': '9687706959, 9687706959, 96877706959, 96877706000, 9687770',
      'ta': '9687706959',
    },
    '7gpq9k5e': {
      'en': 'Gender',
      'hi': 'लिंग',
      'ml': 'ലിംഗഭേദം',
      'ta': 'பாலினம்',
    },
    'ljnqjr4q': {
      'en': 'Female',
      'hi': 'महिला',
      'ml': 'സ്ത്രീ',
      'ta': 'பெண்',
    },
    'v4kvcyrz': {
      'en': 'Current Symptoms',
      'hi': 'वर्तमान लक्षण',
      'ml': 'നിലവിലെ ലക്ഷണങ്ങൾ',
      'ta': 'தற்போதைய அறிகுறிகள்',
    },
    'ips2r1g7': {
      'en': 'Primary Complaint',
      'hi': 'प्राथमिक शिकायत',
      'ml': 'പ്രാഥമിക പരാതി',
      'ta': 'முதன்மை புகார்',
    },
    'n2pehms9': {
      'en': 'Persistent headache and mild fever for the past 3 days',
      'hi': 'पिछले 3 दिनों से लगातार सिरदर्द और हल्का बुखार',
      'ml': 'കഴിഞ്ഞ 3 ദിവസമായി തുടരുന്ന തലവേദനയും നേരിയ പനിയും',
      'ta': 'கடந்த 3 நாட்களாக தொடர்ந்து தலைவலி மற்றும் லேசான காய்ச்சல்',
    },
    '1gmk0wxp': {
      'en': 'Additional Symptoms',
      'hi': 'अतिरिक्त लक्षण',
      'ml': 'അധിക ലക്ഷണങ്ങൾ',
      'ta': 'கூடுதல் அறிகுறிகள்',
    },
    'zv4mxm1d': {
      'en': '• Fatigue\n• Mild nausea\n• Sensitivity to light',
      'hi': '• थकान\n• हल्का मतली\n• प्रकाश के प्रति संवेदनशीलता',
      'ml': '• ക്ഷീണം\n• നേരിയ ഓക്കാനം\n• പ്രകാശത്തോടുള്ള സംവേദനക്ഷമത',
      'ta': '• சோர்வு\n• லேசான குமட்டல்\n• வெளிச்சத்திற்கு உணர்திறன்',
    },
    'nxswa080': {
      'en': 'Allergies & Medications',
      'hi': 'एलर्जी और दवाएं',
      'ml': 'അലർജികളും മരുന്നുകളും',
      'ta': 'ஒவ்வாமைகள் & மருந்துகள்',
    },
    '4wtmjn7f': {
      'en': 'Known Allergies',
      'hi': 'ज्ञात एलर्जी',
      'ml': 'അറിയപ്പെടുന്ന അലർജികൾ',
      'ta': 'அறியப்பட்ட ஒவ்வாமைகள்',
    },
    'ddmcmdp8': {
      'en': '• Penicillin\n• Sulfa drugs\n• Latex',
      'hi': '• पेनिसिलिन\n• सल्फा ड्रग्स\n• लेटेक्स',
      'ml': '• പെൻസിലിൻ\n• സൾഫ മരുന്നുകൾ\n• ലാറ്റക്സ്',
      'ta': '• பென்சிலின்\n• சல்பா மருந்துகள்\n• லேடெக்ஸ்',
    },
    'p2w5pfhu': {
      'en': 'Current Medications',
      'hi': 'वर्तमान दवाएँ',
      'ml': 'നിലവിലുള്ള മരുന്നുകൾ',
      'ta': 'தற்போதைய மருந்துகள்',
    },
    'gzj63res': {
      'en':
          '• Lisinopril 10mg (1x daily)\n• Vitamin D3 2000 IU (1x daily)\n• Ibuprofen 400mg (as needed)',
      'hi':
          '• लिसिनोप्रिल 10mg (1x दैनिक)\n• विटामिन डी3 2000 IU (1x दैनिक)\n• इबुप्रोफेन 400mg (आवश्यकतानुसार)',
      'ml':
          '• ലിസിനോപ്രിൽ 10mg (പ്രതിദിനം 1 തവണ)\n• വിറ്റാമിൻ D3 2000 IU (പ്രതിദിനം 1 തവണ)\n• ഇബുപ്രോഫെൻ 400mg (ആവശ്യാനുസരണം)',
      'ta':
          '• லிசினோபிரில் 10 மிகி (தினசரி 1 முறை)\n• வைட்டமின் D3 2000 IU (தினசரி 1 முறை)\n• இப்யூபுரூஃபன் 400 மிகி (தேவைக்கேற்ப)',
    },
    'irdglvn0': {
      'en': 'Medical History',
      'hi': 'चिकित्सा का इतिहास',
      'ml': 'മെഡിക്കൽ ചരിത്രം',
      'ta': 'மருத்துவ வரலாறு',
    },
    'r97vpw7b': {
      'en': 'Chronic Conditions',
      'hi': 'पुरानी शर्तें',
      'ml': 'വിട്ടുമാറാത്ത അവസ്ഥകൾ',
      'ta': 'நாள்பட்ட நிலைமைகள்',
    },
    '6fh3zfu0': {
      'en': '• Hypertension (diagnosed 2018)\n• Migraine',
      'hi': '• उच्च रक्तचाप (निदान 2018)\n• माइग्रेन',
      'ml': '• രക്താതിമർദ്ദം (2018 ൽ രോഗനിർണയം നടത്തി)\n• മൈഗ്രെയ്ൻ',
      'ta':
          '• உயர் இரத்த அழுத்தம் (2018 இல் கண்டறியப்பட்டது)\n• ஒற்றைத் தலைவலி',
    },
    'idkd2muk': {
      'en': 'Previous Surgeries',
      'hi': 'पिछली सर्जरी',
      'ml': 'മുൻ ശസ്ത്രക്രിയകൾ',
      'ta': 'முந்தைய அறுவை சிகிச்சைகள்',
    },
    'ipf9oq8i': {
      'en': '• Appendectomy (2010)\n• Wisdom teeth removal (2005)',
      'hi': '• एपेंडेक्टोमी (2010)\n• बुद्धि दांत निकालना (2005)',
      'ml': '• അപ്പെൻഡെക്ടമി (2010)\n• ജ്ഞാന പല്ല് നീക്കം ചെയ്യൽ (2005)',
      'ta': '• அப்பென்டெக்டோமி (2010)\n• ஞானப் பற்கள் அகற்றுதல் (2005)',
    },
  },
  // forgotpsswrd
  {
    'l59ywv3t': {
      'en': 'Forgot Password?',
      'hi': 'पासवर्ड भूल गए?',
      'ml': 'പാസ്വേഡ് മറന്നോ?',
      'ta': 'கடவுச்சொல்லை மறந்துவிட்டீர்களா?',
    },
    'p7ot78cr': {
      'en':
          'Enter your email address and we\'ll send you a verification code to reset your password.',
      'hi':
          'अपना ईमेल पता दर्ज करें और हम आपको अपना पासवर्ड रीसेट करने के लिए एक सत्यापन कोड भेजेंगे।',
      'ml':
          'നിങ്ങളുടെ ഇമെയിൽ വിലാസം നൽകുക, നിങ്ങളുടെ പാസ്‌വേഡ് പുനഃസജ്ജമാക്കുന്നതിന് ഞങ്ങൾ ഒരു സ്ഥിരീകരണ കോഡ് അയയ്ക്കും.',
      'ta':
          'உங்கள் மின்னஞ்சல் முகவரியை உள்ளிடவும், உங்கள் கடவுச்சொல்லை மீட்டமைக்க ஒரு சரிபார்ப்புக் குறியீட்டை நாங்கள் உங்களுக்கு அனுப்புவோம்.',
    },
    'top49pn3': {
      'en': 'Email Address',
      'hi': 'मेल पता',
      'ml': 'ഇമെയിൽ വിലാസം',
      'ta': 'மின்னஞ்சல் முகவரி',
    },
    '2t5egvwt': {
      'en': 'Send Code',
      'hi': 'कोड भेजें',
      'ml': 'കോഡ് അയയ്ക്കുക',
      'ta': 'குறியீட்டை அனுப்பு',
    },
    'hpf66o40': {
      'en': 'Enter Verification Code',
      'hi': 'सत्यापन कोड दर्ज करें',
      'ml': 'സ്ഥിരീകരണ കോഡ് നൽകുക',
      'ta': 'சரிபார்ப்புக் குறியீட்டை உள்ளிடவும்',
    },
    'xt9dhqn8': {
      'en': 'Reset Password',
      'hi': 'पासवर्ड रीसेट',
      'ml': 'പാസ്‌വേഡ് പുനഃക്രമീകരിക്കുക',
      'ta': 'கடவுச்சொல்லை மீட்டமைக்க',
    },
    'sp4an3ov': {
      'en': 'Remember your password? ',
      'hi': 'अपना पासवर्ड याद रखें?',
      'ml': 'നിങ്ങളുടെ പാസ്‌വേഡ് ഓർമ്മയുണ്ടോ?',
      'ta': 'உங்கள் கடவுச்சொல் நினைவில் இருக்கிறதா?',
    },
    'y90qxo1d': {
      'en': 'Sign In',
      'hi': 'दाखिल करना',
      'ml': 'സൈൻ ഇൻ',
      'ta': 'உள்நுழை',
    },
  },
  // patientsrecord
  {
    'lpjmlx6q': {
      'en': 'Patient Records',
      'hi': 'मरीज़ों के रिकॉर्ड',
      'ml': 'രോഗി രേഖകൾ',
      'ta': 'நோயாளி பதிவுகள்',
    },
    'wcd0b8yw': {
      'en': 'Recent Patients',
      'hi': 'हाल के मरीज़',
      'ml': 'അടുത്തിടെയുള്ള രോഗികൾ',
      'ta': 'சமீபத்திய நோயாளிகள்',
    },
    '5izkcp18': {
      'en': 'Sarah Johnson',
      'hi': 'सारा जॉनसन',
      'ml': 'സാറാ ജോൺസൺ',
      'ta': 'சாரா ஜான்சன்',
    },
    'a14n0d6i': {
      'en': 'Patient ID: #12345',
      'hi': 'मरीज़ आईडी: #12345',
      'ml': 'രോഗിയുടെ ഐഡി: #12345',
      'ta': 'நோயாளி ஐடி: #12345',
    },
    'j12vf85u': {
      'en': 'Last Visit: May 15, 2023',
      'hi': 'अंतिम विज़िट: 15 मई, 2023',
      'ml': 'അവസാന സന്ദർശനം: മെയ് 15, 2023',
      'ta': 'கடைசி வருகை: மே 15, 2023',
    },
    '4xguex5z': {
      'en': 'Michael John',
      'hi': 'माइकल जॉन',
      'ml': 'മൈക്കൽ ജോൺ',
      'ta': 'மைக்கேல் ஜான்',
    },
    'nitwkdeo': {
      'en': 'Patient ID: #12346',
      'hi': 'मरीज़ आईडी: #12346',
      'ml': 'രോഗിയുടെ ഐഡി: #12346',
      'ta': 'நோயாளி ஐடி: #12346',
    },
    'jv1faafb': {
      'en': 'Last Visit: May 14, 2023',
      'hi': 'अंतिम विज़िट: 14 मई, 2023',
      'ml': 'അവസാന സന്ദർശനം: മെയ് 14, 2023',
      'ta': 'கடைசி வருகை: மே 14, 2023',
    },
    'oc5ecpte': {
      'en': 'Emily paulose',
      'hi': 'एमिली पॉलोज़',
      'ml': 'എമിലി പൗലോസ്',
      'ta': 'எமிலி பவுலோஸ்',
    },
    'ula7h0gp': {
      'en': 'Patient ID: #12347',
      'hi': 'मरीज़ आईडी: #12347',
      'ml': 'രോഗിയുടെ ഐഡി: #12347',
      'ta': 'நோயாளி ஐடி: #12347',
    },
    '2ja8nq1h': {
      'en': 'Last Visit: May 13, 2023',
      'hi': 'अंतिम विज़िट: 13 मई, 2023',
      'ml': 'അവസാന സന്ദർശനം: മെയ് 13, 2023',
      'ta': 'கடைசி வருகை: மே 13, 2023',
    },
  },
  // register
  {
    'ra9s9k06': {
      'en': 'Get Started',
      'hi': 'शुरू हो जाओ',
      'ml': 'ആരംഭിക്കുക',
      'ta': 'தொடங்குங்கள்',
    },
    'pehm0ujp': {
      'en': 'Create an account to access all features.',
      'hi': 'सभी सुविधाओं तक पहुंचने के लिए एक खाता बनाएं।',
      'ml': 'എല്ലാ സവിശേഷതകളും ആക്‌സസ് ചെയ്യാൻ ഒരു അക്കൗണ്ട് സൃഷ്‌ടിക്കുക.',
      'ta': 'அனைத்து அம்சங்களையும் அணுக ஒரு கணக்கை உருவாக்கவும்.',
    },
    '70fjbd68': {
      'en': 'Email Address',
      'hi': 'मेल पता',
      'ml': 'ഇമെയിൽ വിലാസം',
      'ta': 'மின்னஞ்சல் முகவரி',
    },
    '7duc6km7': {
      'en': 'Password',
      'hi': 'पासवर्ड',
      'ml': 'പാസ്‌വേഡ്',
      'ta': 'கடவுச்சொல்',
    },
    '27tj8qyc': {
      'en': 'Confirm Password',
      'hi': 'पासवर्ड की पुष्टि कीजिये',
      'ml': 'പാസ്വേഡ് സ്ഥിരീകരിക്കുക',
      'ta': 'கடவுச்சொல்லை உறுதிப்படுத்தவும்',
    },
    'xqfcmd04': {
      'en': 'Create Account',
      'hi': 'खाता बनाएं',
      'ml': 'അക്കൗണ്ട് സൃഷ്ടിക്കുക',
      'ta': 'கணக்கை உருவாக்கு',
    },
    '4pklmh4j': {
      'en': 'Already have an account? ',
      'hi': 'क्या आपके पास पहले से एक खाता मौजूद है?',
      'ml': 'ഇതിനകം ഒരു അക്കൗണ്ട് ഉണ്ടോ?',
      'ta': 'ஏற்கனவே ஒரு கணக்கு உள்ளதா?',
    },
    'bbglynqb': {
      'en': 'Sign In',
      'hi': 'दाखिल करना',
      'ml': 'സൈൻ ഇൻ',
      'ta': 'உள்நுழை',
    },
  },
  // jameswilson
  {
    '12ehsxa8': {
      'en': 'Appointment Details',
      'hi': 'नियुक्ति विवरण',
      'ml': 'അപ്പോയിന്റ്മെന്റ് വിശദാംശങ്ങൾ',
      'ta': 'முன்பதிவு விவரங்கள்',
    },
    'ux8bsa6s': {
      'en': 'Today, 2:30 PM',
      'hi': 'आज, दोपहर 2:30 बजे',
      'ml': 'ഇന്ന്, ഉച്ചയ്ക്ക് 2:30 ന്',
      'ta': 'இன்று, மதியம் 2:30 மணி',
    },
    'n0ijt4z0': {
      'en': 'General Consultation',
      'hi': 'सामान्य परामर्श',
      'ml': 'പൊതു കൺസൾട്ടേഷൻ',
      'ta': 'பொது ஆலோசனை',
    },
    'f6i96ssr': {
      'en': 'Patient Information',
      'hi': 'रोगी की जानकारी',
      'ml': 'രോഗി വിവരങ്ങൾ',
      'ta': 'நோயாளி தகவல்',
    },
    'l9gy856f': {
      'en': 'Name',
      'hi': 'नाम',
      'ml': 'പേര്',
      'ta': 'பெயர்',
    },
    'gcs9v2d2': {
      'en': 'James Wilson',
      'hi': 'जेम्स विल्सन',
      'ml': 'ജെയിംസ് വിൽസൺ',
      'ta': 'ஜேம்ஸ் வில்சன்',
    },
    '03k850u0': {
      'en': 'Age',
      'hi': 'आयु',
      'ml': 'പ്രായം',
      'ta': 'வயது',
    },
    'ucq0kjtg': {
      'en': '45 years',
      'hi': '45 वर्ष',
      'ml': '45 വർഷം',
      'ta': '45 ஆண்டுகள்',
    },
    'cec5lir3': {
      'en': 'Gender',
      'hi': 'लिंग',
      'ml': 'ലിംഗഭേദം',
      'ta': 'பாலினம்',
    },
    '5crjgfgb': {
      'en': 'Male',
      'hi': 'पुरुष',
      'ml': 'ആൺ',
      'ta': 'ஆண்',
    },
    'bzueiuqf': {
      'en': 'Contact',
      'hi': 'संपर्क',
      'ml': 'ബന്ധപ്പെടുക',
      'ta': 'தொடர்பு',
    },
    '81rhe0om': {
      'en': '+1 (555) 123-4567',
      'hi': '+1 (555) 123-4567',
      'ml': '+1 (555) 123-4567',
      'ta': '+1 (555) 123-4567',
    },
    'ez3rvl0r': {
      'en': 'Appointment Details',
      'hi': 'नियुक्ति विवरण',
      'ml': 'അപ്പോയിന്റ്മെന്റ് വിശദാംശങ്ങൾ',
      'ta': 'முன்பதிவு விவரங்கள்',
    },
    'twt6emxc': {
      'en': 'Doctor',
      'hi': 'चिकित्सक',
      'ml': 'ഡോക്ടർ',
      'ta': 'மருத்துவர்',
    },
    '29l5bq7k': {
      'en': 'Dr. Sarah Johnson',
      'hi': 'डॉ. सारा जॉनसन',
      'ml': 'ഡോ. സാറാ ജോൺസൺ',
      'ta': 'டாக்டர் சாரா ஜான்சன்',
    },
    '74lqk8jl': {
      'en': 'Department',
      'hi': 'विभाग',
      'ml': 'വകുപ്പ്',
      'ta': 'துறை',
    },
    'nib20l7r': {
      'en': 'General Medicine',
      'hi': 'सामान्य दवा',
      'ml': 'ജനറൽ മെഡിസിൻ',
      'ta': 'பொது மருத்துவம்',
    },
    'r1ul9obi': {
      'en': 'Room',
      'hi': 'कमरा',
      'ml': 'മുറി',
      'ta': 'அறை',
    },
    '9ffnhfse': {
      'en': 'Room 204',
      'hi': 'कमरा 204',
      'ml': 'മുറി 204',
      'ta': 'அறை 204',
    },
    'vm8cp0e2': {
      'en': 'Duration',
      'hi': 'अवधि',
      'ml': 'ദൈർഘ്യം',
      'ta': 'கால அளவு',
    },
    'gkxtljps': {
      'en': '30 minutes',
      'hi': '30 मिनट',
      'ml': '30 മിനിറ്റ്',
      'ta': '30 நிமிடங்கள்',
    },
    'ty4q29za': {
      'en': 'Reason for Visit',
      'hi': 'यात्रा का कारण',
      'ml': 'സന്ദർശിക്കാനുള്ള കാരണം',
      'ta': 'வருகைக்கான காரணம்',
    },
    'u1r4hx0p': {
      'en':
          'Regular check-up and blood pressure monitoring. Patient reported mild headaches in the past week.',
      'hi':
          'नियमित जांच और रक्तचाप की निगरानी। रोगी ने पिछले सप्ताह हल्के सिरदर्द की शिकायत की थी।',
      'ml':
          'പതിവ് പരിശോധനയും രക്തസമ്മർദ്ദ നിരീക്ഷണവും. കഴിഞ്ഞ ആഴ്ച രോഗിക്ക് നേരിയ തലവേദന അനുഭവപ്പെട്ടതായി റിപ്പോർട്ട് ചെയ്തു.',
      'ta':
          'வழக்கமான பரிசோதனை மற்றும் இரத்த அழுத்த கண்காணிப்பு. கடந்த வாரத்தில் நோயாளி லேசான தலைவலியைப் புகாரளித்தார்.',
    },
    '8u4yeqsh': {
      'en': 'Cancel',
      'hi': 'रद्द करना',
      'ml': 'റദ്ദാക്കുക',
      'ta': 'ரத்துசெய்',
    },
  },
  // geminii
  {
    'tsfokpne': {
      'en': 'Dr AI',
      'hi': 'डॉ. ए.आई.',
      'ml': 'ഡോ. എ.ഐ.',
      'ta': 'டாக்டர் ஏஐ',
    },
    'evejdgan': {
      'en': 'Ask me anything...',
      'hi': 'मुझसे कुछ भी पूछें...',
      'ml': 'എന്നോട് എന്തെങ്കിലും ചോദിക്കൂ...',
      'ta': 'என்னிடம் ஏதாவது கேள்...',
    },
    '5vtcft80': {
      'en': 'Ask Gemini',
      'hi': 'मिथुन राशि से पूछें',
      'ml': 'മിഥുനത്തോട് ചോദിക്കൂ',
      'ta': 'மிதுன ராசியிடம் கேளுங்கள்',
    },
  },
  // health
  {
    'h1jdq3tg': {
      'en': 'Health Status',
      'hi': 'स्वास्थ्य स्थिति',
      'ml': 'ആരോഗ്യ സ്ഥിതി',
      'ta': 'சுகாதார நிலை',
    },
    'sy9choxd': {
      'en': 'Current Status',
      'hi': 'वर्तमान स्थिति',
      'ml': 'നിലവിലെ സ്ഥിതി',
      'ta': 'தற்போதைய நிலை',
    },
    '8wdp3m1d': {
      'en': 'Good',
      'hi': 'अच्छा',
      'ml': 'നല്ലത്',
      'ta': 'நல்லது',
    },
    'f5v7n9m4': {
      'en':
          'Your health indicators are within normal ranges. Keep up the good work!',
      'hi':
          'आपके स्वास्थ्य संकेतक सामान्य श्रेणी में हैं। अच्छा काम करते रहें!',
      'ml':
          'നിങ്ങളുടെ ആരോഗ്യ സൂചകങ്ങൾ സാധാരണ പരിധിക്കുള്ളിലാണ്. നല്ല പ്രവർത്തനം തുടരുക!',
      'ta':
          'உங்கள் உடல்நலக் குறிகாட்டிகள் இயல்பான வரம்புகளுக்குள் உள்ளன. தொடர்ந்து சிறப்பாகச் செயல்படுங்கள்!',
    },
    '6fid9f42': {
      'en': 'All vitals are normal',
      'hi': 'सभी महत्वपूर्ण अंग सामान्य हैं',
      'ml': 'എല്ലാ ജീവശക്തിയും സാധാരണമാണ്.',
      'ta': 'அனைத்து உயிர்ச்சக்திகளும் இயல்பானவை.',
    },
    '8r4si55l': {
      'en': 'Key Metrics',
      'hi': 'मुख्य मीट्रिक्स',
      'ml': 'കീ മെട്രിക്കുകൾ',
      'ta': 'முக்கிய அளவீடுகள்',
    },
    'u1jt55ex': {
      'en': 'Heart Rate',
      'hi': 'हृदय दर',
      'ml': 'ഹൃദയമിടിപ്പ്',
      'ta': 'இதய துடிப்பு',
    },
    'xu2cffc0': {
      'en': '72 BPM',
      'hi': '72 बीपीएम',
      'ml': '72 ബിപിഎം',
      'ta': '72 பிபிஎம்',
    },
    'x8jr161n': {
      'en': 'Normal',
      'hi': 'सामान्य',
      'ml': 'സാധാരണ',
      'ta': 'இயல்பானது',
    },
    'h749g8aq': {
      'en': 'Blood Pressure',
      'hi': 'रक्तचाप',
      'ml': 'രക്തസമ്മർദ്ദം',
      'ta': 'இரத்த அழுத்தம்',
    },
    '1baa4msd': {
      'en': '120/80',
      'hi': '120/80',
      'ml': '120/80',
      'ta': '120/80 (ஆங்கிலம்)',
    },
    't5gzu229': {
      'en': 'Normal',
      'hi': 'सामान्य',
      'ml': 'സാധാരണ',
      'ta': 'இயல்பானது',
    },
    '05bolm4l': {
      'en': 'Contact Healthcare Provider',
      'hi': 'स्वास्थ्य सेवा प्रदाता से संपर्क करें',
      'ml': 'ആരോഗ്യ സംരക്ഷണ ദാതാവിനെ ബന്ധപ്പെടുക',
      'ta': 'சுகாதார வழங்குநரைத் தொடர்பு கொள்ளவும்',
    },
    'god0kv4r': {
      'en': 'Get health tips from assistant',
      'hi': 'सहायक से स्वास्थ्य संबंधी सुझाव प्राप्त करें',
      'ml': 'അസിസ്റ്റന്റിൽ നിന്ന് ആരോഗ്യ നുറുങ്ങുകൾ നേടൂ',
      'ta': 'உதவியாளரிடமிருந்து உடல்நலக் குறிப்புகளைப் பெறுங்கள்.',
    },
  },
  // emmaedison
  {
    '1i6z4pt6': {
      'en': 'Appointment Details',
      'hi': 'नियुक्ति विवरण',
      'ml': 'അപ്പോയിന്റ്മെന്റ് വിശദാംശങ്ങൾ',
      'ta': 'முன்பதிவு விவரங்கள்',
    },
    'ta1lwnu8': {
      'en': 'Today, 3:00 PM',
      'hi': 'आज, अपराह्न 3:00 बजे',
      'ml': 'ഇന്ന്, ഉച്ചകഴിഞ്ഞ് 3:00 മണിക്ക്',
      'ta': 'இன்று, பிற்பகல் 3:00 மணி',
    },
    '37hhcm8v': {
      'en': 'General Consultation',
      'hi': 'सामान्य परामर्श',
      'ml': 'പൊതു കൺസൾട്ടേഷൻ',
      'ta': 'பொது ஆலோசனை',
    },
    '2pr10mcf': {
      'en': 'Patient Information',
      'hi': 'रोगी की जानकारी',
      'ml': 'രോഗി വിവരങ്ങൾ',
      'ta': 'நோயாளி தகவல்',
    },
    '8qb4s9x7': {
      'en': 'Name',
      'hi': 'नाम',
      'ml': 'പേര്',
      'ta': 'பெயர்',
    },
    'wyyexm02': {
      'en': 'Emma Edison',
      'hi': 'एम्मा एडिसन',
      'ml': 'എമ്മ എഡിസൺ',
      'ta': 'எம்மா எடிசன்',
    },
    '2en1zpio': {
      'en': 'Age',
      'hi': 'आयु',
      'ml': 'പ്രായം',
      'ta': 'வயது',
    },
    'n2ybud1b': {
      'en': '40 years',
      'hi': '40 वर्ष',
      'ml': '40 വർഷം',
      'ta': '40 ஆண்டுகள்',
    },
    'g3am66m1': {
      'en': 'Gender',
      'hi': 'लिंग',
      'ml': 'ലിംഗഭേദം',
      'ta': 'பாலினம்',
    },
    'wbe1up2b': {
      'en': 'female',
      'hi': 'महिला',
      'ml': 'സ്ത്രീ',
      'ta': 'பெண்',
    },
    'goaxbali': {
      'en': 'Contact',
      'hi': 'संपर्क',
      'ml': 'ബന്ധപ്പെടുക',
      'ta': 'தொடர்பு',
    },
    '6jfvsc6j': {
      'en': '+1 (555) 123-4568',
      'hi': '+1 (555) 123-4568',
      'ml': '+1 (555) 123-4568',
      'ta': '+1 (555) 123-4568',
    },
    '6l9a3o7c': {
      'en': 'Appointment Details',
      'hi': 'नियुक्ति विवरण',
      'ml': 'അപ്പോയിന്റ്മെന്റ് വിശദാംശങ്ങൾ',
      'ta': 'முன்பதிவு விவரங்கள்',
    },
    'pfa3wtlc': {
      'en': 'Doctor',
      'hi': 'चिकित्सक',
      'ml': 'ഡോക്ടർ',
      'ta': 'மருத்துவர்',
    },
    'vrfo0q3z': {
      'en': 'Dr. Sarah Johnson',
      'hi': 'डॉ. सारा जॉनसन',
      'ml': 'ഡോ. സാറാ ജോൺസൺ',
      'ta': 'டாக்டர் சாரா ஜான்சன்',
    },
    'or9nz05x': {
      'en': 'Department',
      'hi': 'विभाग',
      'ml': 'വകുപ്പ്',
      'ta': 'துறை',
    },
    's33cskbr': {
      'en': 'General Medicine',
      'hi': 'सामान्य दवा',
      'ml': 'ജനറൽ മെഡിസിൻ',
      'ta': 'பொது மருத்துவம்',
    },
    '3ce4fh43': {
      'en': 'Room',
      'hi': 'कमरा',
      'ml': 'മുറി',
      'ta': 'அறை',
    },
    'x1halmks': {
      'en': 'Room 204',
      'hi': 'कमरा 204',
      'ml': 'മുറി 204',
      'ta': 'அறை 204',
    },
    '4v4cxys5': {
      'en': 'Duration',
      'hi': 'अवधि',
      'ml': 'ദൈർഘ്യം',
      'ta': 'கால அளவு',
    },
    '9wiq9osg': {
      'en': '30 minutes',
      'hi': '30 मिनट',
      'ml': '30 മിനിറ്റ്',
      'ta': '30 நிமிடங்கள்',
    },
    'mp1e25fe': {
      'en': 'Reason for Visit',
      'hi': 'यात्रा का कारण',
      'ml': 'സന്ദർശിക്കാനുള്ള കാരണം',
      'ta': 'வருகைக்கான காரணம்',
    },
    '2s04frqu': {
      'en':
          'Regular check-up and blood pressure monitoring. Patient reported mild body pain in the past week.',
      'hi':
          'नियमित जांच और रक्तचाप की निगरानी। पिछले सप्ताह मरीज ने हल्के शरीर दर्द की शिकायत की।',
      'ml':
          'പതിവ് പരിശോധനയും രക്തസമ്മർദ്ദ നിരീക്ഷണവും. കഴിഞ്ഞ ആഴ്ച രോഗിക്ക് നേരിയ ശരീരവേദന അനുഭവപ്പെട്ടതായി റിപ്പോർട്ട് ചെയ്തു.',
      'ta':
          'வழக்கமான பரிசோதனை மற்றும் இரத்த அழுத்த கண்காணிப்பு. கடந்த வாரத்தில் நோயாளி லேசான உடல் வலியைப் புகாரளித்தார்.',
    },
    '0o2jygzb': {
      'en': 'Cancel',
      'hi': 'रद्द करना',
      'ml': 'റദ്ദാക്കുക',
      'ta': 'ரத்துசெய்',
    },
  },
  // sarahrecord
  {
    '7e3ff2dn': {
      'en': 'Patient Record',
      'hi': 'मरीज़ का रिकॉर्ड',
      'ml': 'രോഗിയുടെ രേഖ',
      'ta': 'நோயாளி பதிவு',
    },
    '685eixud': {
      'en': 'Sarah Johnson',
      'hi': 'सारा जॉनसन',
      'ml': 'സാറാ ജോൺസൺ',
      'ta': 'சாரா ஜான்சன்',
    },
    'd2j97cch': {
      'en': 'Patient ID: #284751',
      'hi': 'मरीज़ आईडी: #284751',
      'ml': 'രോഗിയുടെ ഐഡി: #284751',
      'ta': 'நோயாளி ஐடி: #284751',
    },
    'lxwbv757': {
      'en': 'Basic Information',
      'hi': 'मूल जानकारी',
      'ml': 'അടിസ്ഥാന വിവരങ്ങൾ',
      'ta': 'அடிப்படைத் தகவல்',
    },
    '2stryl22': {
      'en': 'Age',
      'hi': 'आयु',
      'ml': 'പ്രായം',
      'ta': 'வயது',
    },
    'ohxk8uia': {
      'en': '34 years',
      'hi': '34 वर्ष',
      'ml': '34 വർഷം',
      'ta': '34 ஆண்டுகள்',
    },
    'bs3z6rqb': {
      'en': 'Blood Type',
      'hi': 'रक्त प्रकार',
      'ml': 'രക്ത തരം',
      'ta': 'இரத்த வகை',
    },
    '2olcxfaj': {
      'en': 'O+',
      'hi': 'ओ+',
      'ml': 'ഓ+',
      'ta': 'ஓ+',
    },
    '1ts9srd7': {
      'en': 'Height',
      'hi': 'ऊंचाई',
      'ml': 'ഉയരം',
      'ta': 'உயரம்',
    },
    '1ptu7984': {
      'en': '5\'6\"',
      'hi': '5\'6\"',
      'ml': '5\'6\"',
      'ta': '5\'6\"',
    },
    'r65fy8gc': {
      'en': 'Weight',
      'hi': 'वज़न',
      'ml': 'ഭാരം',
      'ta': 'எடை',
    },
    '68ry7422': {
      'en': '145 lbs',
      'hi': '145 पाउंड',
      'ml': '145 പൗണ്ട്',
      'ta': '145 பவுண்டுகள்',
    },
    'jhlo4rwy': {
      'en': 'Current Symptoms',
      'hi': 'वर्तमान लक्षण',
      'ml': 'നിലവിലെ ലക്ഷണങ്ങൾ',
      'ta': 'தற்போதைய அறிகுறிகள்',
    },
    'ygjo001c': {
      'en': 'Severe',
      'hi': 'गंभीर',
      'ml': 'കഠിനമായ',
      'ta': 'கடுமையானது',
    },
    'an6jlcqr': {
      'en':
          '• Persistent migraine headaches\n• Nausea and dizziness\n• Light sensitivity',
      'hi':
          '• लगातार माइग्रेन सिरदर्द\n• मतली और चक्कर आना\n• प्रकाश के प्रति संवेदनशीलता',
      'ml':
          '• സ്ഥിരമായ മൈഗ്രെയ്ൻ തലവേദന\n• ഓക്കാനം, തലകറക്കം\n• പ്രകാശ സംവേദനക്ഷമത',
      'ta':
          '• தொடர்ச்சியான ஒற்றைத் தலைவலி\n• குமட்டல் மற்றும் தலைச்சுற்றல்\n• ஒளி உணர்திறன்',
    },
    'jw4rnfuf': {
      'en': 'Moderate',
      'hi': 'मध्यम',
      'ml': 'മിതമായ',
      'ta': 'மிதமான',
    },
    'xvqgqc3n': {
      'en': '• Fatigue\n• Occasional joint pain\n• Sleep disturbances',
      'hi': '• थकान\n• कभी-कभी जोड़ों में दर्द\n• नींद में गड़बड़ी',
      'ml': '• ക്ഷീണം\n• ഇടയ്ക്കിടെ സന്ധി വേദന\n• ഉറക്ക അസ്വസ്ഥതകൾ',
      'ta': '• சோர்வு\n• அவ்வப்போது மூட்டு வலி\n• தூக்கக் கலக்கம்',
    },
    'quhq2wlr': {
      'en': 'Current Medications',
      'hi': 'वर्तमान दवाएँ',
      'ml': 'നിലവിലുള്ള മരുന്നുകൾ',
      'ta': 'தற்போதைய மருந்துகள்',
    },
    '3m9gill7': {
      'en': 'Sumatriptan',
      'hi': 'सुमाट्रिप्टान',
      'ml': 'സുമാത്രിപ്റ്റാൻ',
      'ta': 'சுமத்ரிப்டன்',
    },
    '3u78jnzr': {
      'en': '50mg tablet, twice daily',
      'hi': '50 मिलीग्राम की गोली, दिन में दो बार',
      'ml': '50mg ടാബ്‌ലെറ്റ്, ദിവസേന രണ്ടുതവണ',
      'ta': '50 மிகி மாத்திரை, தினமும் இரண்டு முறை',
    },
    '1ylcdjpb': {
      'en': 'Active',
      'hi': 'सक्रिय',
      'ml': 'സജീവം',
      'ta': 'செயலில்',
    },
    'uh8gd3p5': {
      'en': 'Propranolol',
      'hi': 'प्रोप्रानोलोल',
      'ml': 'പ്രൊപ്രനോലോൾ',
      'ta': 'ப்ராப்ரானோலோல்',
    },
    'wjjmr6pk': {
      'en': '40mg tablet, once daily',
      'hi': '40 मिलीग्राम की गोली, प्रतिदिन एक बार',
      'ml': '40mg ടാബ്‌ലെറ്റ്, ദിവസത്തിൽ ഒരിക്കൽ',
      'ta': '40 மிகி மாத்திரை, ஒரு நாளைக்கு ஒரு முறை',
    },
    'eq3e0m3u': {
      'en': 'Active',
      'hi': 'सक्रिय',
      'ml': 'സജീവം',
      'ta': 'செயலில்',
    },
    '0ow6vhsa': {
      'en': 'Recent Tests',
      'hi': 'हाल ही में किए गए परीक्षण',
      'ml': 'സമീപകാല ടെസ്റ്റുകൾ',
      'ta': 'சமீபத்திய சோதனைகள்',
    },
    'pwyu3cc6': {
      'en': 'Blood Work Panel',
      'hi': 'रक्त कार्य पैनल',
      'ml': 'ബ്ലഡ് വർക്ക് പാനൽ',
      'ta': 'இரத்த வேலை குழு',
    },
    'kgw7rlzm': {
      'en': 'May 15, 2023',
      'hi': '15 मई, 2023',
      'ml': '2023 മെയ് 15',
      'ta': 'மே 15, 2023',
    },
    '1ghabh6t': {
      'en': 'MRI Scan',
      'hi': 'एमआरआई स्कैन',
      'ml': 'എംആർഐ സ്കാൻ',
      'ta': 'எம்ஆர்ஐ ஸ்கேன்',
    },
    'cs67j0ok': {
      'en': 'May 10, 2023',
      'hi': '10 मई, 2023',
      'ml': '2023 മെയ് 10',
      'ta': 'மே 10, 2023',
    },
    '95v66sfd': {
      'en': 'Notes',
      'hi': 'नोट्स',
      'ml': 'കുറിപ്പുകൾ',
      'ta': 'குறிப்புகள்',
    },
    'gfz5iji7': {
      'en':
          'Patient reports improvement in migraine frequency after starting new medication regimen. Sleep pattern shows slight improvement. Recommended follow-up in 2 weeks to assess medication effectiveness.',
      'hi':
          'मरीज़ ने बताया कि नई दवाई शुरू करने के बाद माइग्रेन की आवृत्ति में सुधार हुआ है। नींद के पैटर्न में थोड़ा सुधार हुआ है। दवाई की प्रभावशीलता का आकलन करने के लिए 2 सप्ताह में अनुवर्ती कार्रवाई की सिफारिश की गई है।',
      'ml':
          'പുതിയ മരുന്ന് ചികിത്സ ആരംഭിച്ചതിനുശേഷം മൈഗ്രേൻ ആവൃത്തിയിൽ പുരോഗതിയുണ്ടെന്ന് രോഗി റിപ്പോർട്ട് ചെയ്യുന്നു. ഉറക്ക രീതിയിൽ നേരിയ പുരോഗതി കാണിക്കുന്നു. മരുന്നുകളുടെ ഫലപ്രാപ്തി വിലയിരുത്തുന്നതിന് 2 ആഴ്ചയ്ക്കുള്ളിൽ ഫോളോ-അപ്പ് ശുപാർശ ചെയ്യുന്നു.',
      'ta':
          'புதிய மருந்து சிகிச்சையைத் தொடங்கிய பிறகு ஒற்றைத் தலைவலி அதிர்வெண்ணில் முன்னேற்றம் இருப்பதாக நோயாளி தெரிவிக்கிறார். தூக்க முறையில் சிறிது முன்னேற்றம் காணப்படுகிறது. மருந்துகளின் செயல்திறனை மதிப்பிடுவதற்கு 2 வாரங்களுக்குப் பிறகு பின்தொடர்தல் பரிந்துரைக்கப்படுகிறது.',
    },
  },
  // bookingroomsuccesfful
  {
    'umim3o8g': {
      'en': 'Room Booking Successful!',
      'hi': 'कमरे की बुकिंग सफल!',
      'ml': 'മുറി ബുക്കിംഗ് വിജയകരം!',
      'ta': 'அறை முன்பதிவு வெற்றிகரமாக முடிந்தது!',
    },
    '4l6ziz58': {
      'en': 'Your reservation has been confirmed',
      'hi': 'आपका आरक्षण पुष्टि हो गया है',
      'ml': 'നിങ്ങളുടെ റിസർവേഷൻ സ്ഥിരീകരിച്ചു.',
      'ta': 'உங்கள் முன்பதிவு உறுதிசெய்யப்பட்டது.',
    },
  },
  // michaeljohnson
  {
    'gql4ebbg': {
      'en': 'Patient Record',
      'hi': 'मरीज़ का रिकॉर्ड',
      'ml': 'രോഗിയുടെ രേഖ',
      'ta': 'நோயாளி பதிவு',
    },
    'fquqbs3v': {
      'en': 'Michael Johnson',
      'hi': 'माइकल जॉनसन',
      'ml': 'മൈക്കൽ ജോൺസൺ',
      'ta': 'மைக்கேல் ஜான்சன்',
    },
    'ycxw6kjh': {
      'en': 'Patient ID: #284751',
      'hi': 'मरीज़ आईडी: #284751',
      'ml': 'രോഗിയുടെ ഐഡി: #284751',
      'ta': 'நோயாளி ஐடி: #284751',
    },
    'dzqi5cd0': {
      'en': 'Basic Information',
      'hi': 'मूल जानकारी',
      'ml': 'അടിസ്ഥാന വിവരങ്ങൾ',
      'ta': 'அடிப்படைத் தகவல்',
    },
    'lhn2m4zw': {
      'en': 'Age',
      'hi': 'आयु',
      'ml': 'പ്രായം',
      'ta': 'வயது',
    },
    'xrsts8ng': {
      'en': '32 years',
      'hi': '32 वर्ष',
      'ml': '32 വർഷം',
      'ta': '32 ஆண்டுகள்',
    },
    '1fdyi8cm': {
      'en': 'Blood Type',
      'hi': 'रक्त प्रकार',
      'ml': 'രക്ത തരം',
      'ta': 'இரத்த வகை',
    },
    'g2or1uxy': {
      'en': 'O+',
      'hi': 'ओ+',
      'ml': 'ഓ+',
      'ta': 'ஓ+',
    },
    'kg1tssyb': {
      'en': 'Height',
      'hi': 'ऊंचाई',
      'ml': 'ഉയരം',
      'ta': 'உயரம்',
    },
    'gq2j32fg': {
      'en': '5\'6\"',
      'hi': '5\'6\"',
      'ml': '5\'6\"',
      'ta': '5\'6\"',
    },
    'fnoo7l5p': {
      'en': 'Weight',
      'hi': 'वज़न',
      'ml': 'ഭാരം',
      'ta': 'எடை',
    },
    'jbpau8wm': {
      'en': '145 lbs',
      'hi': '145 पाउंड',
      'ml': '145 പൗണ്ട്',
      'ta': '145 பவுண்டுகள்',
    },
    'omrdtsu9': {
      'en': 'Current Symptoms',
      'hi': 'वर्तमान लक्षण',
      'ml': 'നിലവിലെ ലക്ഷണങ്ങൾ',
      'ta': 'தற்போதைய அறிகுறிகள்',
    },
    'kyymb6zl': {
      'en': 'Severe',
      'hi': 'गंभीर',
      'ml': 'കഠിനമായ',
      'ta': 'கடுமையானது',
    },
    'nw3lbptt': {
      'en':
          '• Persistent migraine headaches\n• Nausea and dizziness\n• Light sensitivity',
      'hi':
          '• लगातार माइग्रेन सिरदर्द\n• मतली और चक्कर आना\n• प्रकाश के प्रति संवेदनशीलता',
      'ml':
          '• സ്ഥിരമായ മൈഗ്രെയ്ൻ തലവേദന\n• ഓക്കാനം, തലകറക്കം\n• പ്രകാശ സംവേദനക്ഷമത',
      'ta':
          '• தொடர்ச்சியான ஒற்றைத் தலைவலி\n• குமட்டல் மற்றும் தலைச்சுற்றல்\n• ஒளி உணர்திறன்',
    },
    '4r9ni79j': {
      'en': 'Moderate',
      'hi': 'मध्यम',
      'ml': 'മിതമായ',
      'ta': 'மிதமான',
    },
    'aunx943z': {
      'en': '• Fatigue\n• Occasional body pain\n• Sleep disturbances',
      'hi': '• थकान\n• कभी-कभी शरीर में दर्द\n• नींद में गड़बड़ी',
      'ml': '• ക്ഷീണം\n• ഇടയ്ക്കിടെ ശരീരവേദന\n• ഉറക്ക അസ്വസ്ഥതകൾ',
      'ta': '• சோர்வு\n• அவ்வப்போது உடல் வலி\n• தூக்கக் கலக்கம்',
    },
    'n2yzjt2d': {
      'en': 'Current Medications',
      'hi': 'वर्तमान दवाएँ',
      'ml': 'നിലവിലുള്ള മരുന്നുകൾ',
      'ta': 'தற்போதைய மருந்துகள்',
    },
    'uo4wpioq': {
      'en': 'Sumatriptan',
      'hi': 'सुमाट्रिप्टान',
      'ml': 'സുമാത്രിപ്റ്റാൻ',
      'ta': 'சுமத்ரிப்டன்',
    },
    'etbulnai': {
      'en': '50mg tablet, twice daily',
      'hi': '50 मिलीग्राम की गोली, दिन में दो बार',
      'ml': '50mg ടാബ്‌ലെറ്റ്, ദിവസേന രണ്ടുതവണ',
      'ta': '50 மிகி மாத்திரை, தினமும் இரண்டு முறை',
    },
    'rnifuyrj': {
      'en': 'Active',
      'hi': 'सक्रिय',
      'ml': 'സജീവം',
      'ta': 'செயலில்',
    },
    'zvyfdmlm': {
      'en': 'Propranolol',
      'hi': 'प्रोप्रानोलोल',
      'ml': 'പ്രൊപ്രനോലോൾ',
      'ta': 'ப்ராப்ரானோலோல்',
    },
    'lufid4pp': {
      'en': '40mg tablet, once daily',
      'hi': '40 मिलीग्राम की गोली, प्रतिदिन एक बार',
      'ml': '40mg ടാബ്‌ലെറ്റ്, ദിവസത്തിൽ ഒരിക്കൽ',
      'ta': '40 மிகி மாத்திரை, ஒரு நாளைக்கு ஒரு முறை',
    },
    'yo98vx55': {
      'en': 'Active',
      'hi': 'सक्रिय',
      'ml': 'സജീവം',
      'ta': 'செயலில்',
    },
    '6ffv0kvq': {
      'en': 'Recent Tests',
      'hi': 'हाल ही में किए गए परीक्षण',
      'ml': 'സമീപകാല ടെസ്റ്റുകൾ',
      'ta': 'சமீபத்திய சோதனைகள்',
    },
    'gi1c1uzy': {
      'en': 'Blood Work Panel',
      'hi': 'रक्त कार्य पैनल',
      'ml': 'ബ്ലഡ് വർക്ക് പാനൽ',
      'ta': 'இரத்த வேலை குழு',
    },
    'fg6xo5tr': {
      'en': 'May 15, 2023',
      'hi': '15 मई, 2023',
      'ml': '2023 മെയ് 15',
      'ta': 'மே 15, 2023',
    },
    'buca3c57': {
      'en': 'MRI Scan',
      'hi': 'एमआरआई स्कैन',
      'ml': 'എംആർഐ സ്കാൻ',
      'ta': 'எம்ஆர்ஐ ஸ்கேன்',
    },
    'vp6ks8xs': {
      'en': 'May 10, 2023',
      'hi': '10 मई, 2023',
      'ml': '2023 മെയ് 10',
      'ta': 'மே 10, 2023',
    },
    'wogfa11f': {
      'en': 'Notes',
      'hi': 'नोट्स',
      'ml': 'കുറിപ്പുകൾ',
      'ta': 'குறிப்புகள்',
    },
    'grp2u5c2': {
      'en':
          'Patient reports improvement in migraine frequency after starting new medication regimen. Sleep pattern shows slight improvement. Recommended follow-up in 2 weeks to assess medication effectiveness.',
      'hi':
          'मरीज़ ने बताया कि नई दवाई शुरू करने के बाद माइग्रेन की आवृत्ति में सुधार हुआ है। नींद के पैटर्न में थोड़ा सुधार हुआ है। दवाई की प्रभावशीलता का आकलन करने के लिए 2 सप्ताह में अनुवर्ती कार्रवाई की सिफारिश की गई है।',
      'ml':
          'പുതിയ മരുന്ന് ചികിത്സ ആരംഭിച്ചതിനുശേഷം മൈഗ്രേൻ ആവൃത്തിയിൽ പുരോഗതിയുണ്ടെന്ന് രോഗി റിപ്പോർട്ട് ചെയ്യുന്നു. ഉറക്ക രീതിയിൽ നേരിയ പുരോഗതി കാണിക്കുന്നു. മരുന്നുകളുടെ ഫലപ്രാപ്തി വിലയിരുത്തുന്നതിന് 2 ആഴ്ചയ്ക്കുള്ളിൽ ഫോളോ-അപ്പ് ശുപാർശ ചെയ്യുന്നു.',
      'ta':
          'புதிய மருந்து சிகிச்சையைத் தொடங்கிய பிறகு ஒற்றைத் தலைவலி அதிர்வெண்ணில் முன்னேற்றம் இருப்பதாக நோயாளி தெரிவிக்கிறார். தூக்க முறையில் சிறிது முன்னேற்றம் காணப்படுகிறது. மருந்துகளின் செயல்திறனை மதிப்பிடுவதற்கு 2 வாரங்களுக்குப் பிறகு பின்தொடர்தல் பரிந்துரைக்கப்படுகிறது.',
    },
  },
  // Emilypaulose
  {
    'a8cykvid': {
      'en': 'Patient Record',
      'hi': 'मरीज़ का रिकॉर्ड',
      'ml': 'രോഗിയുടെ രേഖ',
      'ta': 'நோயாளி பதிவு',
    },
    'k3u50mon': {
      'en': 'Emily paulose',
      'hi': 'एमिली पॉलोज़',
      'ml': 'എമിലി പൗലോസ്',
      'ta': 'எமிலி பவுலோஸ்',
    },
    'ng6j0y70': {
      'en': 'Patient ID: #284751',
      'hi': 'मरीज़ आईडी: #284751',
      'ml': 'രോഗിയുടെ ഐഡി: #284751',
      'ta': 'நோயாளி ஐடி: #284751',
    },
    'xgpbzyuw': {
      'en': 'Basic Information',
      'hi': 'मूल जानकारी',
      'ml': 'അടിസ്ഥാന വിവരങ്ങൾ',
      'ta': 'அடிப்படைத் தகவல்',
    },
    '0pwy5l8i': {
      'en': 'Age',
      'hi': 'आयु',
      'ml': 'പ്രായം',
      'ta': 'வயது',
    },
    'gl85tlos': {
      'en': '22 years',
      'hi': '22 साल का',
      'ml': '22 വർഷം',
      'ta': '22 ஆண்டுகள்',
    },
    'vbbz8lb8': {
      'en': 'Blood Type',
      'hi': 'रक्त प्रकार',
      'ml': 'രക്ത തരം',
      'ta': 'இரத்த வகை',
    },
    'xud3pt6b': {
      'en': 'O+',
      'hi': 'ओ+',
      'ml': 'ഓ+',
      'ta': 'ஓ+',
    },
    'm1irprdg': {
      'en': 'Height',
      'hi': 'ऊंचाई',
      'ml': 'ഉയരം',
      'ta': 'உயரம்',
    },
    'ma1wb3zt': {
      'en': '5\'6\"',
      'hi': '5\'6\"',
      'ml': '5\'6\"',
      'ta': '5\'6\"',
    },
    'ui6ugo69': {
      'en': 'Weight',
      'hi': 'वज़न',
      'ml': 'ഭാരം',
      'ta': 'எடை',
    },
    'oia5k89z': {
      'en': '145 lbs',
      'hi': '145 पाउंड',
      'ml': '145 പൗണ്ട്',
      'ta': '145 பவுண்டுகள்',
    },
    's1yvzktm': {
      'en': 'Current Symptoms',
      'hi': 'वर्तमान लक्षण',
      'ml': 'നിലവിലെ ലക്ഷണങ്ങൾ',
      'ta': 'தற்போதைய அறிகுறிகள்',
    },
    'jtoes9wc': {
      'en': 'Severe',
      'hi': 'गंभीर',
      'ml': 'കഠിനമായ',
      'ta': 'கடுமையானது',
    },
    'uaxci2nj': {
      'en':
          '• Persistent migraine headaches\n• Nausea and dizziness\n• Light sensitivity',
      'hi':
          '• लगातार माइग्रेन सिरदर्द\n• मतली और चक्कर आना\n• प्रकाश के प्रति संवेदनशीलता',
      'ml':
          '• സ്ഥിരമായ മൈഗ്രെയ്ൻ തലവേദന\n• ഓക്കാനം, തലകറക്കം\n• പ്രകാശ സംവേദനക്ഷമത',
      'ta':
          '• தொடர்ச்சியான ஒற்றைத் தலைவலி\n• குமட்டல் மற்றும் தலைச்சுற்றல்\n• ஒளி உணர்திறன்',
    },
    'j0egifrv': {
      'en': 'Moderate',
      'hi': 'मध्यम',
      'ml': 'മിതമായ',
      'ta': 'மிதமான',
    },
    'asvrv9th': {
      'en': '• Fatigue\n• Occasional vomiting\n• Sleep disturbances',
      'hi': '• थकान\n• कभी-कभी उल्टी आना\n• नींद में गड़बड़ी',
      'ml': '• ക്ഷീണം\n• ഇടയ്ക്കിടെ ഛർദ്ദി\n• ഉറക്ക അസ്വസ്ഥതകൾ',
      'ta': '• சோர்வு\n• அவ்வப்போது வாந்தி\n• தூக்கக் கலக்கம்',
    },
    'qnxi5bct': {
      'en': 'Current Medications',
      'hi': 'वर्तमान दवाएँ',
      'ml': 'നിലവിലുള്ള മരുന്നുകൾ',
      'ta': 'தற்போதைய மருந்துகள்',
    },
    'xbodxex2': {
      'en': 'Sumatriptan',
      'hi': 'सुमाट्रिप्टान',
      'ml': 'സുമാത്രിപ്റ്റാൻ',
      'ta': 'சுமத்ரிப்டன்',
    },
    'j8lhfcju': {
      'en': '50mg tablet, twice daily',
      'hi': '50 मिलीग्राम की गोली, दिन में दो बार',
      'ml': '50mg ടാബ്‌ലെറ്റ്, ദിവസേന രണ്ടുതവണ',
      'ta': '50 மிகி மாத்திரை, தினமும் இரண்டு முறை',
    },
    'iekwelzz': {
      'en': 'Active',
      'hi': 'सक्रिय',
      'ml': 'സജീവം',
      'ta': 'செயலில்',
    },
    'qbp7jgu3': {
      'en': 'Propranolol',
      'hi': 'प्रोप्रानोलोल',
      'ml': 'പ്രൊപ്രനോലോൾ',
      'ta': 'ப்ராப்ரானோலோல்',
    },
    'ond2pe3k': {
      'en': '40mg tablet, once daily',
      'hi': '40 मिलीग्राम की गोली, प्रतिदिन एक बार',
      'ml': '40mg ടാബ്‌ലെറ്റ്, ദിവസത്തിൽ ഒരിക്കൽ',
      'ta': '40 மிகி மாத்திரை, ஒரு நாளைக்கு ஒரு முறை',
    },
    'lwnuzbpj': {
      'en': 'Active',
      'hi': 'सक्रिय',
      'ml': 'സജീവം',
      'ta': 'செயலில்',
    },
    'glx8jjzw': {
      'en': 'Recent Tests',
      'hi': 'हाल ही में किए गए परीक्षण',
      'ml': 'സമീപകാല ടെസ്റ്റുകൾ',
      'ta': 'சமீபத்திய சோதனைகள்',
    },
    '5mbjukzb': {
      'en': 'Blood Work Panel',
      'hi': 'रक्त कार्य पैनल',
      'ml': 'ബ്ലഡ് വർക്ക് പാനൽ',
      'ta': 'இரத்த வேலை குழு',
    },
    'zxq7hpci': {
      'en': 'May 15, 2023',
      'hi': '15 मई, 2023',
      'ml': '2023 മെയ് 15',
      'ta': 'மே 15, 2023',
    },
    'olxu3goi': {
      'en': 'MRI Scan',
      'hi': 'एमआरआई स्कैन',
      'ml': 'എംആർഐ സ്കാൻ',
      'ta': 'எம்ஆர்ஐ ஸ்கேன்',
    },
    'mwalo4gs': {
      'en': 'May 10, 2023',
      'hi': '10 मई, 2023',
      'ml': '2023 മെയ് 10',
      'ta': 'மே 10, 2023',
    },
    'pbv1tjxw': {
      'en': 'Notes',
      'hi': 'नोट्स',
      'ml': 'കുറിപ്പുകൾ',
      'ta': 'குறிப்புகள்',
    },
    'srfwfask': {
      'en':
          'Patient reports improvement in migraine frequency after starting new medication regimen. Sleep pattern shows slight improvement. Recommended follow-up in 2 weeks to assess medication effectiveness.',
      'hi':
          'मरीज़ ने बताया कि नई दवाई शुरू करने के बाद माइग्रेन की आवृत्ति में सुधार हुआ है। नींद के पैटर्न में थोड़ा सुधार हुआ है। दवाई की प्रभावशीलता का आकलन करने के लिए 2 सप्ताह में अनुवर्ती कार्रवाई की सिफारिश की गई है।',
      'ml':
          'പുതിയ മരുന്ന് ചികിത്സ ആരംഭിച്ചതിനുശേഷം മൈഗ്രേൻ ആവൃത്തിയിൽ പുരോഗതിയുണ്ടെന്ന് രോഗി റിപ്പോർട്ട് ചെയ്യുന്നു. ഉറക്ക രീതിയിൽ നേരിയ പുരോഗതി കാണിക്കുന്നു. മരുന്നുകളുടെ ഫലപ്രാപ്തി വിലയിരുത്തുന്നതിന് 2 ആഴ്ചയ്ക്കുള്ളിൽ ഫോളോ-അപ്പ് ശുപാർശ ചെയ്യുന്നു.',
      'ta':
          'புதிய மருந்து சிகிச்சையைத் தொடங்கிய பிறகு ஒற்றைத் தலைவலி அதிர்வெண்ணில் முன்னேற்றம் இருப்பதாக நோயாளி தெரிவிக்கிறார். தூக்க முறையில் சிறிது முன்னேற்றம் காணப்படுகிறது. மருந்துகளின் செயல்திறனை மதிப்பிடுவதற்கு 2 வாரங்களுக்குப் பிறகு பின்தொடர்தல் பரிந்துரைக்கப்படுகிறது.',
    },
  },
  // healthai
  {
    'p4a9okyb': {
      'en': 'Health AI',
      'hi': 'स्वास्थ्य एआई',
      'ml': 'ആരോഗ്യ AI',
      'ta': 'உடல்நலம் AI',
    },
    'pw07w1yf': {
      'en': 'Ask me anything...',
      'hi': 'मुझसे कुछ भी पूछें...',
      'ml': 'എന്നോട് എന്തെങ്കിലും ചോദിക്കൂ...',
      'ta': 'என்னிடம் ஏதாவது கேள்...',
    },
    'yqloocrk': {
      'en': 'Ask Health AI',
      'hi': 'स्वास्थ्य एआई से पूछें',
      'ml': 'ആസ്ക് ഹെൽത്ത് AI',
      'ta': 'கேளுங்கள் ஆரோக்கியம் AI',
    },
  },
  // success
  {
    'hk8z728p': {
      'en': 'Success!',
      'hi': 'सफलता!',
      'ml': 'വിജയം!',
      'ta': 'வெற்றி!',
    },
    '1bi07d2f': {
      'en': 'Your request has been submitted successfully',
      'hi': 'आपका अनुरोध सफलतापूर्वक सबमिट कर दिया गया है',
      'ml': 'നിങ്ങളുടെ അഭ്യർത്ഥന വിജയകരമായി സമർപ്പിച്ചു.',
      'ta': 'உங்கள் கோரிக்கை வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது.',
    },
    '6qhpla5f': {
      'en': 'We\'ll process your request and get back to you shortly',
      'hi': 'हम आपके अनुरोध पर कार्रवाई करेंगे और शीघ्र ही आपसे संपर्क करेंगे',
      'ml':
          'ഞങ്ങൾ നിങ്ങളുടെ അഭ്യർത്ഥന പ്രോസസ്സ് ചെയ്യുകയും ഉടൻ തന്നെ നിങ്ങളെ ബന്ധപ്പെടുകയും ചെയ്യും.',
      'ta':
          'உங்கள் கோரிக்கையைச் செயல்படுத்தி, விரைவில் உங்களைத் தொடர்புகொள்வோம்.',
    },
    '2xnou7nq': {
      'en': 'Back to Home',
      'hi': 'घर वापिस जा रहा हूँ',
      'ml': 'വീട്ടിലേക്ക് മടങ്ങുക',
      'ta': 'வீட்டிற்குத் திரும்பு',
    },
  },
  // patientsrecordCopy
  {
    'x0sly39l': {
      'en': 'Patient Records',
      'hi': 'मरीज़ों के रिकॉर्ड',
      'ml': 'രോഗി രേഖകൾ',
      'ta': 'நோயாளி பதிவுகள்',
    },
    'l3mx33c6': {
      'en': 'Recent Patients',
      'hi': 'हाल के मरीज़',
      'ml': 'അടുത്തിടെയുള്ള രോഗികൾ',
      'ta': 'சமீபத்திய நோயாளிகள்',
    },
    'wrl0o514': {
      'en': 'Sarah Johnson',
      'hi': 'सारा जॉनसन',
      'ml': 'സാറാ ജോൺസൺ',
      'ta': 'சாரா ஜான்சன்',
    },
    'pclb71zv': {
      'en': 'Patient ID: #12345',
      'hi': 'मरीज़ आईडी: #12345',
      'ml': 'രോഗിയുടെ ഐഡി: #12345',
      'ta': 'நோயாளி ஐடி: #12345',
    },
    's54mqdvj': {
      'en': 'Last Visit: May 15, 2023',
      'hi': 'अंतिम विज़िट: 15 मई, 2023',
      'ml': 'അവസാന സന്ദർശനം: മെയ് 15, 2023',
      'ta': 'கடைசி வருகை: மே 15, 2023',
    },
    'bb7b7wpz': {
      'en': 'Michael John',
      'hi': 'माइकल जॉन',
      'ml': 'മൈക്കൽ ജോൺ',
      'ta': 'மைக்கேல் ஜான்',
    },
    'csxos4q5': {
      'en': 'Patient ID: #12346',
      'hi': 'मरीज़ आईडी: #12346',
      'ml': 'രോഗിയുടെ ഐഡി: #12346',
      'ta': 'நோயாளி ஐடி: #12346',
    },
    '4jey50sk': {
      'en': 'Last Visit: May 14, 2023',
      'hi': 'अंतिम विज़िट: 14 मई, 2023',
      'ml': 'അവസാന സന്ദർശനം: മെയ് 14, 2023',
      'ta': 'கடைசி வருகை: மே 14, 2023',
    },
    '1eq1vvem': {
      'en': 'Emily paulose',
      'hi': 'एमिली पॉलोज़',
      'ml': 'എമിലി പൗലോസ്',
      'ta': 'எமிலி பவுலோஸ்',
    },
    '0x2lkmkf': {
      'en': 'Patient ID: #12347',
      'hi': 'मरीज़ आईडी: #12347',
      'ml': 'രോഗിയുടെ ഐഡി: #12347',
      'ta': 'நோயாளி ஐடி: #12347',
    },
    'xpcq859v': {
      'en': 'Last Visit: May 13, 2023',
      'hi': 'अंतिम विज़िट: 13 मई, 2023',
      'ml': 'അവസാന സന്ദർശനം: മെയ് 13, 2023',
      'ta': 'கடைசி வருகை: மே 13, 2023',
    },
  },
  // chat
  {
    'dys20i36': {
      'en': 'Sarah Johnson',
      'hi': 'सारा जॉनसन',
      'ml': 'സാറാ ജോൺസൺ',
      'ta': 'சாரா ஜான்சன்',
    },
    'ighltrc6': {
      'en': 'Online',
      'hi': 'ऑनलाइन',
      'ml': 'ഓൺലൈൻ',
      'ta': 'நிகழ்நிலை',
    },
    '7bl7g96i': {
      'en': 'Hi! How are you doing today?',
      'hi': 'नमस्ते आप आज कैसे हैं?',
      'ml': 'ഹായ്! ഇന്ന് എങ്ങനെയുണ്ട്?',
      'ta': 'ஹாய்! இன்னைக்கு எப்படி இருக்கீங்க?',
    },
    'xj0d88fz': {
      'en': '10:30 AM',
      'hi': 'सुबह 10:30:00 बजे',
      'ml': 'രാവിലെ 10:30',
      'ta': 'காலை 10:30 மணி',
    },
    'y9ijv6hn': {
      'en': 'Hey! I\'m doing great, thanks for asking. How about you?',
      'hi': 'अरे! मैं बहुत अच्छा हूँ, पूछने के लिए धन्यवाद। आपका क्या हाल है?',
      'ml': 'ഹേയ്! എനിക്ക് സുഖമാണ്, ചോദിച്ചതിന് നന്ദി. എങ്ങനെയുണ്ട്?',
      'ta':
          'ஹேய்! நான் நல்லா இருக்கேன், கேட்டதற்கு நன்றி. நீங்க எப்படி இருக்கீங்க?',
    },
    'uqgvogff': {
      'en': '10:31 AM',
      'hi': '10:31 पूर्वाह्न',
      'ml': 'രാവിലെ 10:31',
      'ta': 'காலை 10:31',
    },
    '2fu3aeiy': {
      'en':
          'I\'m good too! Just wanted to check if we\'re still on for coffee tomorrow?',
      'hi':
          'मैं भी ठीक हूँ! बस यह जानना चाहता था कि क्या हम कल कॉफ़ी के लिए तैयार हैं?',
      'ml':
          'എനിക്കും സുഖമാണ്! നാളെയും നമുക്ക് കാപ്പി കുടിക്കാൻ ഉണ്ടോ എന്ന് നോക്കാൻ വേണ്ടിയായിരുന്നു?',
      'ta':
          'நானும் நல்லா இருக்கேன்! நாளைக்கு இன்னும் காஃபி குடிக்கலாமான்னு பார்க்கணும்னு நினைச்சேன்?',
    },
    'n81b7rtb': {
      'en': '10:32 AM',
      'hi': '10:32 पूर्वाह्न',
      'ml': 'രാവിലെ 10:32',
      'ta': 'காலை 10:32',
    },
    '4ncf2je5': {
      'en': 'Absolutely! Looking forward to it. Same place at 2 PM?',
      'hi': 'बिल्कुल! इसका बेसब्री से इंतजार है। दोपहर 2 बजे भी वही जगह?',
      'ml':
          'തീർച്ചയായും! അതിനായി കാത്തിരിക്കുന്നു. ഉച്ചയ്ക്ക് 2 മണിക്ക് അതേ സ്ഥലം തന്നെയാണോ?',
      'ta': 'கண்டிப்பா! ஆவலுடன் காத்திருக்கிறேன். மதியம் 2 மணிக்கு அதே இடமா?',
    },
    'zcm26rji': {
      'en': '10:33 AM',
      'hi': '10:33 पूर्वाह्न',
      'ml': 'രാവിലെ 10:33',
      'ta': 'காலை 10:33',
    },
    'dxykawyc': {
      'en': 'Perfect! See you then! 😊',
      'hi': 'बढ़िया! फिर मिलते हैं! 😊',
      'ml': 'പെർഫെക്റ്റ്! പിന്നെ കാണാം! 😊',
      'ta': 'அருமை! அப்புறம் சந்திப்போம்! 😊',
    },
    'zjt2ykdv': {
      'en': '10:34 AM',
      'hi': '10:34 पूर्वाह्न',
      'ml': 'രാവിലെ 10:34',
      'ta': 'காலை 10:34',
    },
    'cq28qyhy': {
      'en': 'Type a message...',
      'hi': 'संदेश लिखें...',
      'ml': 'ഒരു സന്ദേശം ടൈപ്പ് ചെയ്യുക...',
      'ta': 'ஒரு செய்தியை தட்டச்சு செய்யவும்...',
    },
  },
  // deficiency
  {
    '9haewtik': {
      'en': 'Patient Deficiencies',
      'hi': 'रोगी की कमियाँ',
      'ml': 'രോഗിയുടെ കുറവുകൾ',
      'ta': 'நோயாளி குறைபாடுகள்',
    },
    '7f66c3qv': {
      'en': 'Sarah Johnson',
      'hi': 'सारा जॉनसन',
      'ml': 'സാറാ ജോൺസൺ',
      'ta': 'சாரா ஜான்சன்',
    },
    'q5yd0jok': {
      'en': 'Critical',
      'hi': 'गंभीर',
      'ml': 'ഗുരുതരം',
      'ta': 'முக்கியமான',
    },
    'ax2jv6ey': {
      'en': 'Vitamin D',
      'hi': 'विटामिन डी',
      'ml': 'വിറ്റാമിൻ ഡി',
      'ta': 'வைட்டமின் டி',
    },
    'wavk39f5': {
      'en': '12 ng/mL',
      'hi': '12 एनजी/एमएल',
      'ml': '12 എൻജി/മില്ലിലിറ്റർ',
      'ta': '12 என்ஜி/மிலி',
    },
    'vxewr4wn': {
      'en': 'Iron',
      'hi': 'लोहा',
      'ml': 'ഇരുമ്പ്',
      'ta': 'இரும்பு',
    },
    '9flve4wx': {
      'en': '8 μg/dL',
      'hi': '8 माइक्रोग्राम/डीएल',
      'ml': '8 μg/dL',
      'ta': '8 μg/டெசிலிட்டர்',
    },
    'iuudhnzk': {
      'en': 'Recommended: Vitamin D supplements and iron-rich diet',
      'hi': 'अनुशंसित: विटामिन डी की खुराक और आयरन युक्त आहार',
      'ml':
          'ശുപാർശ ചെയ്യുന്നത്: വിറ്റാമിൻ ഡി സപ്ലിമെന്റുകളും ഇരുമ്പ് സമ്പുഷ്ടമായ ഭക്ഷണക്രമവും',
      'ta':
          'பரிந்துரைக்கப்படுகிறது: வைட்டமின் டி சப்ளிமெண்ட்ஸ் மற்றும் இரும்புச்சத்து நிறைந்த உணவு',
    },
    'rhjw9222': {
      'en': 'Michael John',
      'hi': 'माइकल जॉन',
      'ml': 'മൈക്കൽ ജോൺ',
      'ta': 'மைக்கேல் ஜான்',
    },
    '5f1fuito': {
      'en': 'Moderate',
      'hi': 'मध्यम',
      'ml': 'മിതമായ',
      'ta': 'மிதமான',
    },
    'ifqsnbxw': {
      'en': 'Vitamin B12',
      'hi': 'विटामिन बी 12',
      'ml': 'വിറ്റാമിൻ ബി 12',
      'ta': 'வைட்டமின் பி12',
    },
    'kksrnlrf': {
      'en': '200 pg/mL',
      'hi': '200 पीजी/एमएल',
      'ml': '200 പിജി/മില്ലിലി',
      'ta': '200 பக்.கி/மிலி.',
    },
    'yki5aogp': {
      'en': 'Magnesium',
      'hi': 'मैगनीशियम',
      'ml': 'മഗ്നീഷ്യം',
      'ta': 'மெக்னீசியம்',
    },
    'z4g5hztp': {
      'en': '1.5 mg/dL',
      'hi': '1.5 मिलीग्राम/डीएल',
      'ml': '1.5 മി.ഗ്രാം/ഡെ.ലി.',
      'ta': '1.5 மி.கி/டெ.லி.',
    },
    '2ae5x5ze': {
      'en': 'Recommended: B12 injections and magnesium supplements',
      'hi': 'अनुशंसित: बी12 इंजेक्शन और मैग्नीशियम सप्लीमेंट',
      'ml':
          'ശുപാർശ ചെയ്യുന്നത്: ബി12 കുത്തിവയ്പ്പുകളും മഗ്നീഷ്യം സപ്ലിമെന്റുകളും',
      'ta':
          'பரிந்துரைக்கப்படுகிறது: பி12 ஊசிகள் மற்றும் மெக்னீசியம் சப்ளிமெண்ட்ஸ்',
    },
    'q3li6njv': {
      'en': 'Emily Paulose',
      'hi': 'एमिली पॉलोज़',
      'ml': 'എമിലി പൗലോസ്',
      'ta': 'எமிலி பவுலோஸ்',
    },
    'sh50ul62': {
      'en': 'Mild',
      'hi': 'हल्का',
      'ml': 'സൗമ്യം',
      'ta': 'லேசானது',
    },
    'd2n7e8k1': {
      'en': 'Zinc',
      'hi': 'जस्ता',
      'ml': 'സിങ്ക്',
      'ta': 'துத்தநாகம்',
    },
    'xqmws7u5': {
      'en': '60 μg/dL',
      'hi': '60 माइक्रोग्राम/डीएल',
      'ml': '60 μg/dL',
      'ta': '60 μg/டெசிலிட்டர்',
    },
    'paecxj8p': {
      'en': 'Vitamin C',
      'hi': 'विटामिन सी',
      'ml': 'വിറ്റാമിൻ സി',
      'ta': 'வைட்டமின் சி',
    },
    'y8q4qqh8': {
      'en': '45 mg/L',
      'hi': '45 मिलीग्राम/लीटर',
      'ml': '45 മി.ഗ്രാം/ലി',
      'ta': '45 மி.கி/லி',
    },
    'nz0xj9gv': {
      'en': 'Recommended: Zinc supplements and vitamin C rich foods',
      'hi': 'अनुशंसित: जिंक सप्लीमेंट्स और विटामिन सी युक्त खाद्य पदार्थ',
      'ml':
          'ശുപാർശ ചെയ്യുന്നത്: സിങ്ക് സപ്ലിമെന്റുകളും വിറ്റാമിൻ സി സമ്പുഷ്ടമായ ഭക്ഷണങ്ങളും',
      'ta':
          'பரிந்துரைக்கப்படுகிறது: துத்தநாக சப்ளிமெண்ட்ஸ் மற்றும் வைட்டமின் சி நிறைந்த உணவுகள்',
    },
    'xixb643o': {
      'en': 'Actions Required',
      'hi': 'आवश्यक कार्यवाहियाँ',
      'ml': 'ആവശ്യമായ പ്രവർത്തനങ്ങൾ',
      'ta': 'தேவையான நடவடிக்கைகள்',
    },
    'ga58xbdz': {
      'en': 'Update Records',
      'hi': 'रिकॉर्ड अपडेट करें',
      'ml': 'റെക്കോർഡുകൾ അപ്ഡേറ്റ് ചെയ്യുക',
      'ta': 'பதிவுகளைப் புதுப்பிக்கவும்',
    },
  },
  // duties
  {
    'xfzxfvqi': {
      'en': 'Today\'s Duties',
      'hi': 'आज के कर्तव्य',
      'ml': 'ഇന്നത്തെ കടമകൾ',
      'ta': 'இன்றைய கடமைகள்',
    },
    'pvib74xb': {
      'en': 'Thursday, 15 June',
      'hi': 'गुरुवार, 15 जून',
      'ml': 'വ്യാഴാഴ്ച, ജൂൺ 15',
      'ta': 'வியாழன், 15 ஜூன்',
    },
    '3mcmta4t': {
      'en': 'Area Summary',
      'hi': 'क्षेत्र सारांश',
      'ml': 'ഏരിയ സംഗ്രഹം',
      'ta': 'பகுதி சுருக்கம்',
    },
    '2svwckyz': {
      'en': '12',
      'hi': '12',
      'ml': '12',
      'ta': '12',
    },
    'p5edwso5': {
      'en': 'Households',
      'hi': 'परिवारों',
      'ml': 'വീട്ടുകാർ',
      'ta': 'குடும்பங்கள்',
    },
    '4i9rksdm': {
      'en': '5',
      'hi': '5',
      'ml': '5',
      'ta': '5',
    },
    'ob17gdrb': {
      'en': 'Pregnant Women',
      'hi': 'प्रेग्नेंट औरत',
      'ml': 'ഗർഭിണികൾ',
      'ta': 'கர்ப்பிணி பெண்கள்',
    },
    '6b0izrx1': {
      'en': '8',
      'hi': '8',
      'ml': '8',
      'ta': '8',
    },
    'dkj4qd7x': {
      'en': 'Children <5',
      'hi': 'बच्चे <5',
      'ml': 'കുട്ടികൾ <5',
      'ta': 'குழந்தைகள் <5',
    },
    '01kx61o6': {
      'en': 'Today\'s Tasks',
      'hi': 'आज के कार्य',
      'ml': 'ഇന്നത്തെ ടാസ്‌ക്കുകൾ',
      'ta': 'இன்றைய பணிகள்',
    },
    'mj8gb7g0': {
      'en': 'Antenatal Check-up',
      'hi': 'प्रसवपूर्व जांच',
      'ml': 'പ്രസവപൂർവ പരിശോധന',
      'ta': 'மகப்பேறுக்கு முந்தைய பரிசோதனை',
    },
    'ano4uyxb': {
      'en': 'Meera Devi • House #45',
      'hi': 'मीरा देवी • मकान #45',
      'ml': 'മീരാ ദേവി • വീട് #45',
      'ta': 'மீரா தேவி • வீடு #45',
    },
    '19ydejpw': {
      'en': '10:00 AM',
      'hi': '10:00 AM',
      'ml': 'രാവിലെ 10:00',
      'ta': 'காலை 10:00 மணி',
    },
    '875auama': {
      'en': 'Immunization Visit',
      'hi': 'टीकाकरण यात्रा',
      'ml': 'രോഗപ്രതിരോധ സന്ദർശനം',
      'ta': 'நோய்த்தடுப்பு வருகை',
    },
    'ymfizk53': {
      'en': 'Raju Kumar • House #23',
      'hi': 'राजू कुमार • मकान #23',
      'ml': 'രാജു കുമാർ • വീട് #23',
      'ta': 'ராஜு குமார் • வீடு #23',
    },
    'ebumnyib': {
      'en': '11:30 AM',
      'hi': '11:30:00 बजे सुबह',
      'ml': 'രാവിലെ 11:30',
      'ta': 'காலை 11:30 மணி',
    },
    'i7cndked': {
      'en': 'Health Education',
      'hi': 'स्वास्थ्य शिक्षा',
      'ml': 'ആരോഗ്യ വിദ്യാഭ്യാസം',
      'ta': 'சுகாதார கல்வி',
    },
    'keir0qw1': {
      'en': 'Community Center',
      'hi': 'सामुदायिक केंद्र',
      'ml': 'കമ്മ്യൂണിറ്റി സെന്റർ',
      'ta': 'சமூக மையம்',
    },
    'b6r3dl7e': {
      'en': '2:00 PM',
      'hi': '2:00 अपराह्न',
      'ml': 'ഉച്ചയ്ക്ക് 2:00',
      'ta': 'பிற்பகல் 2:00 மணி',
    },
    'h8xazgf7': {
      'en': 'Medicine Distribution',
      'hi': 'दवा वितरण',
      'ml': 'ഔഷധ വിതരണം',
      'ta': 'மருந்து விநியோகம்',
    },
    's76oiiy9': {
      'en': 'Lakshmi • House #78',
      'hi': 'लक्ष्मी • मकान #78',
      'ml': 'ലക്ഷ്മി • വീട് #78',
      'ta': 'லட்சுமி • வீடு #78',
    },
    'a1txx3dj': {
      'en': '4:30 PM',
      'hi': '4:30 अपराह्न',
      'ml': 'വൈകുന്നേരം 4:30',
      'ta': 'மாலை 4:30 மணி',
    },
    'i8yw2scj': {
      'en': 'Important Notes',
      'hi': 'महत्वपूर्ण नोट्स',
      'ml': 'പ്രധാന കുറിപ്പുകൾ',
      'ta': 'முக்கிய குறிப்புகள்',
    },
    'kx20gw2q': {
      'en': '• Bring vaccination records for immunization visit',
      'hi': '• टीकाकरण यात्रा के लिए टीकाकरण रिकॉर्ड साथ लाएँ',
      'ml': '• രോഗപ്രതിരോധ സന്ദർശനത്തിനായി വാക്സിനേഷൻ രേഖകൾ കൊണ്ടുവരിക.',
      'ta': '• நோய்த்தடுப்பு வருகைக்காக தடுப்பூசி பதிவுகளை கொண்டு வாருங்கள்.',
    },
    'oxgtzlx7': {
      'en': '• Collect monthly report from supervisor',
      'hi': '• पर्यवेक्षक से मासिक रिपोर्ट एकत्र करें',
      'ml': '• സൂപ്പർവൈസറിൽ നിന്ന് പ്രതിമാസ റിപ്പോർട്ട് ശേഖരിക്കുക',
      'ta': '• மேற்பார்வையாளரிடமிருந்து மாதாந்திர அறிக்கையைச் சேகரிக்கவும்.',
    },
    'zcb4m2mo': {
      'en': '• Update household survey data',
      'hi': '• घरेलू सर्वेक्षण डेटा अपडेट करें',
      'ml': '• ഗാർഹിക സർവേ ഡാറ്റ അപ്ഡേറ്റ് ചെയ്യുക',
      'ta': '• வீட்டு கணக்கெடுப்பு தரவைப் புதுப்பிக்கவும்',
    },
  },
  // reportsawhp
  {
    'xmphzzal': {
      'en': 'Reports Dashboard',
      'hi': 'रिपोर्ट डैशबोर्ड',
      'ml': 'റിപ്പോർട്ട് ഡാഷ്‌ബോർഡ്',
      'ta': 'அறிக்கைகள் டாஷ்போர்டு',
    },
    'qe4kln2g': {
      'en': 'Health Worker Activity Summary',
      'hi': 'स्वास्थ्य कार्यकर्ता गतिविधि सारांश',
      'ml': 'ആരോഗ്യ പ്രവർത്തക പ്രവർത്തന സംഗ്രഹം',
      'ta': 'சுகாதாரப் பணியாளர் செயல்பாடு சுருக்கம்',
    },
    'bcieb8ca': {
      'en': 'Monthly Statistics',
      'hi': 'मासिक आंकड़े',
      'ml': 'പ്രതിമാസ സ്ഥിതിവിവരക്കണക്കുകൾ',
      'ta': 'மாதாந்திர புள்ளிவிவரங்கள்',
    },
    'z2miov21': {
      'en': '156',
      'hi': '156',
      'ml': '156 (അറബിക്)',
      'ta': '156 தமிழ்',
    },
    '6e0bmjih': {
      'en': 'House Visits',
      'hi': 'घर का दौरा',
      'ml': 'വീട് സന്ദർശനങ്ങൾ',
      'ta': 'வீடுகளுக்குச் சென்று பார்த்தல்',
    },
    'ht7zmwfj': {
      'en': '42',
      'hi': '42',
      'ml': '42 \n\n42\n\n',
      'ta': '42 (அ)',
    },
    'gutpg7ci': {
      'en': 'Referrals',
      'hi': 'रेफरल',
      'ml': 'റഫറലുകൾ',
      'ta': 'பரிந்துரைகள்',
    },
    '14m69xn6': {
      'en': '89',
      'hi': '89',
      'ml': '89 अनुका',
      'ta': '89 (ஆங்கிலம்)',
    },
    'fnqkrxtg': {
      'en': 'Cases Resolved',
      'hi': 'सुलझाए गए मामले',
      'ml': 'പരിഹരിച്ച കേസുകൾ',
      'ta': 'தீர்க்கப்பட்ட வழக்குகள்',
    },
    '3hfzvtkv': {
      'en': 'Recent Activities',
      'hi': 'हाल की गतिविधियाँ',
      'ml': 'സമീപകാല പ്രവർത്തനങ്ങൾ',
      'ta': 'சமீபத்திய செயல்பாடுகள்',
    },
    'rk7vpw3y': {
      'en': 'Prenatal Checkup',
      'hi': 'प्रसव पूर्व जांच',
      'ml': 'പ്രസവപൂർവ പരിശോധന',
      'ta': 'மகப்பேறுக்கு முந்தைய பரிசோதனை',
    },
    'qisfhj30': {
      'en': 'Sarah Johnson • Ward 5',
      'hi': 'सारा जॉनसन • वार्ड 5',
      'ml': 'സാറാ ജോൺസൺ • വാർഡ് 5',
      'ta': 'சாரா ஜான்சன் • வார்டு 5',
    },
    'joofhrho': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
      'ml': 'പൂർത്തിയായി',
      'ta': 'நிறைவு',
    },
    '9uvtkiv3': {
      'en': 'Vaccination Drive',
      'hi': 'टीकाकरण अभियान',
      'ml': 'വാക്സിനേഷൻ ഡ്രൈവ്',
      'ta': 'தடுப்பூசி இயக்கம்',
    },
    'pkh5e4jr': {
      'en': 'Community Center • Ward 3',
      'hi': 'सामुदायिक केंद्र • वार्ड 3',
      'ml': 'കമ്മ്യൂണിറ്റി സെന്റർ • വാർഡ് 3',
      'ta': 'சமூக மையம் • வார்டு 3',
    },
    '35hiasc2': {
      'en': 'In Progress',
      'hi': 'प्रगति पर है',
      'ml': 'പുരോഗതിയിൽ',
      'ta': 'செயல்பாட்டில் உள்ளது',
    },
    'gn2tf6ni': {
      'en': 'Health Survey',
      'hi': 'स्वास्थ्य सर्वेक्षण',
      'ml': 'ആരോഗ്യ സർവേ',
      'ta': 'சுகாதார ஆய்வு',
    },
    'bcwh4nwy': {
      'en': 'Robert Smith • Ward 4',
      'hi': 'रॉबर्ट स्मिथ • वार्ड 4',
      'ml': 'റോബർട്ട് സ്മിത്ത് • വാർഡ് 4',
      'ta': 'ராபர்ட் ஸ்மித் • வார்டு 4',
    },
    'd0x05och': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
      'ml': 'പൂർത്തിയായി',
      'ta': 'முடிந்தது',
    },
    'wsobuoby': {
      'en': 'Health Metrics',
      'hi': 'स्वास्थ्य मेट्रिक्स',
      'ml': 'ആരോഗ്യ അളവുകൾ',
      'ta': 'சுகாதார அளவீடுகள்',
    },
    'ng1xd54u': {
      'en': 'Vaccination Coverage',
      'hi': 'टीकाकरण कवरेज',
      'ml': 'വാക്സിനേഷൻ കവറേജ്',
      'ta': 'தடுப்பூசி காப்பீடு',
    },
    'vjbqlxg9': {
      'en': '78%',
      'hi': '78%',
      'ml': '78%',
      'ta': '78%',
    },
    'bd7i4r89': {
      'en': 'Maternal Health Visits',
      'hi': 'मातृ स्वास्थ्य दौरे',
      'ml': 'മാതൃ ആരോഗ്യ സന്ദർശനങ്ങൾ',
      'ta': 'தாய்வழி சுகாதார வருகைகள்',
    },
    'y711zzxw': {
      'en': '92%',
      'hi': '92%',
      'ml': '92%',
      'ta': '92%',
    },
    'tvalcjuk': {
      'en': 'Child Health Monitoring',
      'hi': 'बाल स्वास्थ्य निगरानी',
      'ml': 'കുട്ടികളുടെ ആരോഗ്യ നിരീക്ഷണം',
      'ta': 'குழந்தை சுகாதார கண்காணிப்பு',
    },
    'cxk1s99n': {
      'en': '85%',
      'hi': '85%',
      'ml': '85%',
      'ta': '85%',
    },
    '556z4s5i': {
      'en': 'Upcoming Tasks',
      'hi': 'आगामी कार्य',
      'ml': 'വരാനിരിക്കുന്ന ടാസ്‌ക്കുകൾ',
      'ta': 'வரவிருக்கும் பணிகள்',
    },
    's8op22n4': {
      'en': 'Community Health Camp',
      'hi': 'सामुदायिक स्वास्थ्य शिविर',
      'ml': 'കമ്മ്യൂണിറ്റി ഹെൽത്ത് ക്യാമ്പ്',
      'ta': 'சமூக சுகாதார முகாம்',
    },
    'nvnamq3y': {
      'en': 'Tomorrow',
      'hi': 'कल',
      'ml': 'നാളെ',
      'ta': 'நாளை',
    },
    'zye51yua': {
      'en': 'Nutrition Workshop',
      'hi': 'पोषण कार्यशाला',
      'ml': 'പോഷകാഹാര ശില്പശാല',
      'ta': 'ஊட்டச்சத்து பட்டறை',
    },
    'u0jl0lxc': {
      'en': 'In 3 days',
      'hi': 'तीन दिनों में',
      'ml': '3 ദിവസത്തിനുള്ളിൽ',
      'ta': '3 நாட்களில்',
    },
    'jxu01bux': {
      'en': 'Immunization Drive',
      'hi': 'टीकाकरण अभियान',
      'ml': 'രോഗപ്രതിരോധ ഡ്രൈവ്',
      'ta': 'நோய்த்தடுப்பு இயக்கம்',
    },
    'ortgkfmt': {
      'en': 'Next Week',
      'hi': 'अगले सप्ताह',
      'ml': 'അടുത്ത ആഴ്ച',
      'ta': 'அடுத்த வாரம்',
    },
  },
  // providernumber
  {
    'aqnpvcjj': {
      'en': 'Emergency Contact',
      'hi': 'आपातकालीन संपर्क',
      'ml': 'അടിയന്തര കോൺടാക്റ്റ്',
      'ta': 'அவசர தொடர்பு',
    },
    'ipph7ni7': {
      'en': 'Call this number for immediate assistance',
      'hi': 'तत्काल सहायता के लिए इस नंबर पर कॉल करें',
      'ml': 'അടിയന്തര സഹായത്തിനായി ഈ നമ്പറിൽ വിളിക്കുക.',
      'ta': 'உடனடி உதவிக்கு இந்த எண்ணை அழைக்கவும்.',
    },
    '4i3ub75x': {
      'en': '+91 8606454274',
      'hi': '+91 8606454274',
      'ml': '+91 8606454274',
      'ta': '+91 8606454274',
    },
    '1fzygkqh': {
      'en': 'Available 24/7',
      'hi': '24/7 उपलब्ध',
      'ml': '24/7 ലഭ്യമാണ്',
      'ta': '24/7 கிடைக்கும்',
    },
    'lgs9if15': {
      'en': 'Call Now',
      'hi': 'अब कॉल करें',
      'ml': 'ഇപ്പോൾ വിളിക്കൂ',
      'ta': 'இப்போது அழைக்கவும்',
    },
  },
  // request
  {
    'uhqxjc6c': {
      'en': 'Request Successful!',
      'hi': 'अनुरोध सफल!',
      'ml': 'അഭ്യർത്ഥന വിജയകരം!',
      'ta': 'கோரிக்கை வெற்றியடைந்தது!',
    },
    '7jjx70s5': {
      'en':
          'Your request has been submitted successfully. A healthcare provider will contact you shortly.',
      'hi':
          'आपका अनुरोध सफलतापूर्वक सबमिट कर दिया गया है। एक स्वास्थ्य सेवा प्रदाता जल्द ही आपसे संपर्क करेगा।',
      'ml':
          'നിങ്ങളുടെ അഭ്യർത്ഥന വിജയകരമായി സമർപ്പിച്ചു. ഒരു ആരോഗ്യ സംരക്ഷണ ദാതാവ് ഉടൻ നിങ്ങളെ ബന്ധപ്പെടും.',
      'ta':
          'உங்கள் கோரிக்கை வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது. ஒரு சுகாதார வழங்குநர் விரைவில் உங்களைத் தொடர்புகொள்வார்.',
    },
    'dyi6rdl1': {
      'en': 'Back to Home',
      'hi': 'घर वापिस जा रहा हूँ',
      'ml': 'വീട്ടിലേക്ക് മടങ്ങുക',
      'ta': 'வீட்டிற்குத் திரும்பு',
    },
  },
  // prescriptions
  {
    'h3z09ine': {
      'en': 'Prescription History',
      'hi': 'प्रिस्क्रिप्शन इतिहास',
      'ml': 'കുറിപ്പടി ചരിത്രം',
      'ta': 'மருந்து வரலாறு',
    },
    'yg71t7a5': {
      'en': 'Recent Patient Prescriptions',
      'hi': 'हाल ही में मरीजों के पर्चे',
      'ml': 'രോഗിയുടെ സമീപകാല കുറിപ്പടികൾ',
      'ta': 'சமீபத்திய நோயாளி மருந்துச்சீட்டுகள்',
    },
    'nydjbh8t': {
      'en': 'Sarah Johnson',
      'hi': 'सारा जॉनसन',
      'ml': 'സാറാ ജോൺസൺ',
      'ta': 'சாரா ஜான்சன்',
    },
    '6cgl3hi3': {
      'en': 'Prescribed today at 2:30 PM',
      'hi': 'आज दोपहर 2:30 बजे निर्धारित',
      'ml': 'ഇന്ന് ഉച്ചയ്ക്ക് 2:30 ന് നിർദ്ദേശിച്ചു',
      'ta': 'இன்று மதியம் 2:30 மணிக்கு பரிந்துரைக்கப்பட்டது',
    },
    'c28bpnip': {
      'en': 'Prescribed Medications',
      'hi': 'निर्धारित दवाएं',
      'ml': 'നിർദ്ദേശിച്ച മരുന്നുകൾ',
      'ta': 'பரிந்துரைக்கப்பட்ட மருந்துகள்',
    },
    'iem657n8': {
      'en':
          '• Ibuprofen 400mg - 1 tablet every 6 hours\n         text 24 - content \"Duration: 7 days',
      'hi':
          '• इबुप्रोफेन 400mg - हर 6 घंटे में 1 गोली\nपाठ 24 - सामग्री \"अवधि: 7 दिन',
      'ml':
          '• ഇബുപ്രോഫെൻ 400mg - ഓരോ 6 മണിക്കൂറിലും 1 ടാബ്‌ലെറ്റ്\nടെക്സ്റ്റ് 24 - ഉള്ളടക്കം \"ദൈർഘ്യം: 7 ദിവസം',
      'ta':
          '• இப்யூபுரூஃபன் 400 மிகி - ஒவ்வொரு 6 மணி நேரத்திற்கும் 1 மாத்திரை\nஉரை 24 - உள்ளடக்கம் \"காலம்: 7 நாட்கள்',
    },
    'yu3t95pi': {
      'en': 'Diagnosis: Migraine with nausea',
      'hi': 'निदान: मतली के साथ माइग्रेन',
      'ml': 'രോഗനിർണയം: ഓക്കാനത്തോടുകൂടിയ മൈഗ്രെയ്ൻ',
      'ta': 'நோய் கண்டறிதல்: குமட்டலுடன் கூடிய ஒற்றைத் தலைவலி',
    },
    'c3b5vko4': {
      'en': 'Michael john',
      'hi': 'माइकल जॉन',
      'ml': 'മൈക്കൽ ജോൺ',
      'ta': 'மைக்கேல் ஜான்',
    },
    'g43vuw7d': {
      'en': 'Prescribed yesterday at 4:15 PM',
      'hi': 'कल शाम 4:15 बजे निर्धारित किया गया',
      'ml': 'ഇന്നലെ വൈകുന്നേരം 4:15 ന് നിർദ്ദേശിച്ചത്',
      'ta': 'நேற்று மாலை 4:15 மணிக்கு பரிந்துரைக்கப்பட்டது',
    },
    'zemyxrr0': {
      'en': 'Prescribed Medications',
      'hi': 'निर्धारित दवाएं',
      'ml': 'നിർദ്ദേശിച്ച മരുന്നുകൾ',
      'ta': 'பரிந்துரைக்கப்பட்ட மருந்துகள்',
    },
    'vz6t3fbg': {
      'en':
          '• Amoxicillin 500mg - 1 capsule every 8 hours\n         text 38 - content \"Duration: 5 days',
      'hi':
          '• एमोक्सिसिलिन 500mg - हर 8 घंटे में 1 कैप्सूल\nटेक्स्ट 38 - सामग्री \"अवधि: 5 दिन',
      'ml':
          '• അമോക്സിസില്ലിൻ 500mg - ഓരോ 8 മണിക്കൂറിലും 1 കാപ്സ്യൂൾ\nടെക്സ്റ്റ് 38 - ഉള്ളടക്കം \"ദൈർഘ്യം: 5 ദിവസം',
      'ta':
          '• அமோக்ஸிசிலின் 500 மிகி - ஒவ்வொரு 8 மணி நேரத்திற்கும் 1 காப்ஸ்யூல்\nஉரை 38 - உள்ளடக்கம் \"காலம்: 5 நாட்கள்',
    },
    's1eutmkb': {
      'en': 'Diagnosis: Upper respiratory tract infection',
      'hi': 'निदान: ऊपरी श्वसन पथ का संक्रमण',
      'ml': 'രോഗനിർണയം: മുകളിലെ ശ്വാസകോശ ലഘുലേഖ അണുബാധ',
      'ta': 'நோய் கண்டறிதல்: மேல் சுவாசக்குழாய் தொற்று',
    },
    'eyvopka0': {
      'en': 'Emily Davis',
      'hi': 'एमिली डेविस',
      'ml': 'എമിലി ഡേവിസ്',
      'ta': 'எமிலி டேவிஸ்',
    },
    '20e0ykb0': {
      'en': 'Prescribed 2 days ago at 11:20 AM',
      'hi': '2 दिन पहले 11:20 बजे निर्धारित',
      'ml': '2 ദിവസം മുമ്പ് രാവിലെ 11:20 ന് നിർദ്ദേശിച്ചത്',
      'ta': '2 நாட்களுக்கு முன்பு காலை 11:20 மணிக்கு பரிந்துரைக்கப்பட்டது.',
    },
    'z52q7sw2': {
      'en': 'Prescribed Medications',
      'hi': 'निर्धारित दवाएं',
      'ml': 'നിർദ്ദേശിച്ച മരുന്നുകൾ',
      'ta': 'பரிந்துரைக்கப்பட்ட மருந்துகள்',
    },
    't0y9q2y0': {
      'en':
          '• Metformin 500mg - 1 tablet twice daily\n         text 52 - content \"Duration: 30 days',
      'hi':
          '• मेटफॉर्मिन 500mg - 1 गोली दिन में दो बार\nपाठ 52 - सामग्री \"अवधि: 30 दिन',
      'ml':
          '• മെറ്റ്ഫോർമിൻ 500mg - 1 ടാബ്‌ലെറ്റ് ദിവസേന രണ്ടുതവണ\nവാചകം 52 - ഉള്ളടക്കം \"ദൈർഘ്യം: 30 ദിവസം',
      'ta':
          '• மெட்ஃபோர்மின் 500 மிகி - ஒரு நாளைக்கு இரண்டு முறை 1 மாத்திரை\nஉரை 52 - உள்ளடக்கம் \"காலம்: 30 நாட்கள்',
    },
    '4ey84f24': {
      'en': 'Diagnosis: Type 2 Diabetes, Hypertension',
      'hi': 'निदान: टाइप 2 मधुमेह, उच्च रक्तचाप',
      'ml': 'രോഗനിർണയം: ടൈപ്പ് 2 പ്രമേഹം, രക്താതിമർദ്ദം',
      'ta': 'நோய் கண்டறிதல்: வகை 2 நீரிழிவு நோய், உயர் இரத்த அழுத்தம்',
    },
    '5rbrkk8q': {
      'en': 'James Wilson',
      'hi': 'जेम्स विल्सन',
      'ml': 'ജെയിംസ് വിൽസൺ',
      'ta': 'ஜேம்ஸ் வில்சன்',
    },
    'n4t9fc7q': {
      'en': 'Prescribed 3 days ago at 3:45 PM',
      'hi': '3 दिन पहले 3:45 PM पर निर्धारित',
      'ml': '3 ദിവസം മുമ്പ് ഉച്ചകഴിഞ്ഞ് 3:45 ന് നിർദ്ദേശിച്ചത്',
      'ta': '3 நாட்களுக்கு முன்பு பிற்பகல் 3:45 மணிக்கு பரிந்துரைக்கப்பட்டது',
    },
    'l0q6aaxp': {
      'en': 'Prescribed Medications',
      'hi': 'निर्धारित दवाएं',
      'ml': 'നിർദ്ദേശിച്ച മരുന്നുകൾ',
      'ta': 'பரிந்துரைக்கப்பட்ட மருந்துகள்',
    },
    '79vnbth6': {
      'en':
          '• Omeprazole 20mg - 1 capsule daily\n         text 66 - content \"Duration: 14 days',
      'hi':
          '• ओमेप्राज़ोल 20mg - 1 कैप्सूल प्रतिदिन\nपाठ 66 - सामग्री \"अवधि: 14 दिन',
      'ml':
          '• ഒമേപ്രാസോൾ 20mg - പ്രതിദിനം 1 കാപ്സ്യൂൾ\nടെക്സ്റ്റ് 66 - ഉള്ളടക്കം \"ദൈർഘ്യം: 14 ദിവസം',
      'ta':
          '• ஒமேப்ரஸோல் 20 மிகி - தினமும் 1 காப்ஸ்யூல்\nஉரை 66 - உள்ளடக்கம் \"காலம்: 14 நாட்கள்',
    },
    '5k0wkc72': {
      'en': 'Diagnosis: Gastroesophageal reflux disease (GERD)',
      'hi': 'निदान: गैस्ट्रोएसोफेगल रिफ्लक्स रोग (जीईआरडी)',
      'ml': 'രോഗനിർണയം: ഗ്യാസ്ട്രോ ഈസോഫേഷ്യൽ റിഫ്ലക്സ് രോഗം (GERD)',
      'ta': 'நோய் கண்டறிதல்: இரைப்பைஉணவுக்குழாய் ரிஃப்ளக்ஸ் நோய் (GERD)',
    },
  },
  // settings
  {
    '9cw4dmse': {
      'en': 'Settings',
      'hi': 'सेटिंग्स',
      'ml': 'ക്രമീകരണങ്ങൾ',
      'ta': 'அமைப்புகள்',
    },
    'ukst5khm': {
      'en': 'Account Settings',
      'hi': 'अकाउंट सेटिंग',
      'ml': 'അക്കൗണ്ട് ക്രമീകരണങ്ങൾ',
      'ta': 'கணக்கு அமைப்புகள்',
    },
    'nu96ljrs': {
      'en': 'Language',
      'hi': 'भाषा',
      'ml': 'ഭാഷ',
      'ta': 'மொழி',
    },
    'go1upxl0': {
      'en': 'Privacy & Security',
      'hi': 'निजता एवं सुरक्षा',
      'ml': 'സ്വകാര്യതയും സുരക്ഷയും',
      'ta': 'தனியுரிமை & பாதுகாப்பு',
    },
    '8qthnicv': {
      'en': 'Professional Settings',
      'hi': 'व्यावसायिक सेटिंग्स',
      'ml': 'പ്രൊഫഷണൽ ക്രമീകരണങ്ങൾ',
      'ta': 'தொழில்முறை அமைப்புகள்',
    },
    'tu8obkhc': {
      'en': 'Working Hours',
      'hi': 'कार्य के घंटे',
      'ml': 'പ്രവൃത്തി സമയം',
      'ta': 'வேலை நேரம்',
    },
    'mm3qkzwg': {
      'en': 'Availability',
      'hi': 'उपलब्धता',
      'ml': 'ലഭ്യത',
      'ta': 'கிடைக்கும் தன்மை',
    },
    'ju5zjx2s': {
      'en': 'Payment Settings',
      'hi': 'भुगतान सेटिंग',
      'ml': 'പേയ്‌മെന്റ് ക്രമീകരണങ്ങൾ',
      'ta': 'கட்டண அமைப்புகள்',
    },
    '5nb01aqy': {
      'en': 'Help & Support',
      'hi': 'सहायता एवं समर्थन',
      'ml': 'സഹായവും പിന്തുണയും',
      'ta': 'உதவி & ஆதரவு',
    },
    'so6j4c42': {
      'en': 'FAQs',
      'hi': 'पूछे जाने वाले प्रश्न',
      'ml': 'പതിവ് ചോദ്യങ്ങൾ',
      'ta': 'அடிக்கடி கேட்கப்படும் கேள்விகள்',
    },
    's7dfy04q': {
      'en': 'Contact Support',
      'hi': 'समर्थन से संपर्क करें',
      'ml': 'പിന്തുണയെ ബന്ധപ്പെടുക',
      'ta': 'ஆதரவைத் தொடர்பு கொள்ளவும்',
    },
    'lx4izen1': {
      'en': 'About',
      'hi': 'के बारे में',
      'ml': 'കുറിച്ച്',
      'ta': 'பற்றி',
    },
    'x7o5ccy1': {
      'en': 'Log Out',
      'hi': 'लॉग आउट',
      'ml': 'ലോഗ് ഔട്ട് ചെയ്യുക',
      'ta': 'வெளியேறு',
    },
  },
  // language
  {
    'tvmdgdau': {
      'en': 'Language Settings',
      'hi': 'भाषा सेटिंग्स',
      'ml': 'ഭാഷാ ക്രമീകരണങ്ങൾ',
      'ta': 'மொழி அமைப்புகள்',
    },
    'xyc5c8i6': {
      'en': 'Select Your Preferred Language',
      'hi': 'अपनी पसंदीदा भाषा चुनें',
      'ml': 'നിങ്ങളുടെ ഇഷ്ടപ്പെട്ട ഭാഷ തിരഞ്ഞെടുക്കുക',
      'ta': 'உங்களுக்கு விருப்பமான மொழியைத் தேர்ந்தெடுக்கவும்',
    },
    'm13fggx2': {
      'en': 'Save Changes',
      'hi': 'परिवर्तनों को सुरक्षित करें',
      'ml': 'മാറ്റങ്ങൾ സംരക്ഷിക്കുക',
      'ta': 'மாற்றங்களைச் சேமிக்கவும்',
    },
  },
  // Miscellaneous
  {
    '8bc2z0ny': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'shq86k9p': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'gqhrwxg1': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '6ra2jvxu': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'z7y7r29a': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'g00bohg5': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'yx7oqa1v': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '08a6298u': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ih5ogemp': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'pdf2ie3w': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'glxwiim8': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '98ovbf0l': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'hp4xqoqo': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'm1yjlbej': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    't417kmf2': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'vckma3rv': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'oknzl0iq': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'v1jfwyvw': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'yq7mromf': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'o66auzqk': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'qjy2h5yq': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'nbbtwtm5': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'lf09mjqb': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '9fv42w8j': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'vi0rzs5v': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
].reduce((a, b) => a..addAll(b));
