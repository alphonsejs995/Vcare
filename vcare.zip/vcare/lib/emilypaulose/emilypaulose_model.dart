import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'emilypaulose_widget.dart' show EmilypauloseWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EmilypauloseModel extends FlutterFlowModel<EmilypauloseWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
