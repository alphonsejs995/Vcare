import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDcLdN7oOVDK1pABZw65HwM3j--7YcUicY",
            authDomain: "example-f9d9c.firebaseapp.com",
            projectId: "example-f9d9c",
            storageBucket: "example-f9d9c.firebasestorage.app",
            messagingSenderId: "612658102242",
            appId: "1:612658102242:web:ee26082b6527a7cb4803bb",
            measurementId: "G-W2M70MVLRG"));
  } else {
    await Firebase.initializeApp();
  }
}
